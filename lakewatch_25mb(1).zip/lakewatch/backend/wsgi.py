"""Точка входа для боевого WSGI-сервера, например: gunicorn --chdir backend wsgi:app"""

from lakewatch.api import create_app

app = create_app()
