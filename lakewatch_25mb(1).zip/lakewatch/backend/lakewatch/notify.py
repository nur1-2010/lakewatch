"""Уведомления в Telegram при переходе озера в тревожное состояние."""

from __future__ import annotations

import json
import logging
import urllib.request

from .service import LakeService

log = logging.getLogger(__name__)

STATUS_TEXT_RU = {
    "rapid_rise": "быстрый рост площади",
    "new_lake": "появилось новое озеро",
    "rising": "наблюдается рост площади",
}


def pending_notifications(service: LakeService) -> list[dict]:
    """Озёра, состояние которых стало тревожным с прошлого уведомления."""
    out = []
    for s in service.alerts():
        if service.storage.last_notified_status(s["id"]) != s["status"]:
            out.append(s)
    return out


def format_message(summaries: list[dict], site_url: str | None = None) -> str:
    lines = ["LakeWatch · Иле-Алатау"]
    for s in summaries:
        cur = s["current"]["area_m2"] if s.get("current") else None
        pct = s.get("change_vs_normal_pct")
        extra = f", {cur:,} м²".replace(",", " ") if cur is not None else ""
        extra += f" ({pct:+.0f}% к норме)" if pct is not None and s["status"] != "new_lake" else ""
        lines.append(f"⚠ {s['name']['ru']}: {STATUS_TEXT_RU.get(s['status'], s['status'])}{extra}")
    if site_url:
        lines.append(site_url)
    lines.append("Это не официальное предупреждение. Официальная информация — МЧС РК / Казселезащита.")
    return "\n".join(lines)


def send_telegram(service: LakeService, site_url: str | None = None) -> int:
    s = service.settings
    pending = pending_notifications(service)
    if not pending:
        return 0
    if not (s.telegram_bot_token and s.telegram_chat_id):
        log.info("Telegram не настроен; новых тревог: %d", len(pending))
        return 0
    body = json.dumps({"chat_id": s.telegram_chat_id, "text": format_message(pending, site_url)}).encode()
    req = urllib.request.Request(f"https://api.telegram.org/bot{s.telegram_bot_token}/sendMessage",
                                 body, {"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30):
        pass
    for p in pending:
        service.storage.set_notified_status(p["id"], p["status"])
    return len(pending)
