"""Командная строка: python -m lakewatch <команда>.

  update       докачать новые снимки и пересчитать картинки
  serve        запустить сайт локально
  status       показать состояние озёр в консоли
  import-csv   перенести данные из первого прототипа
  notify       отправить тревоги в Telegram (если настроен)
"""

from __future__ import annotations

import argparse
import logging
import sys
from datetime import date
from pathlib import Path

from .lakes import load_lakes
from .service import LakeService
from .settings import Settings
from .storage import Storage


def _service(settings: Settings) -> LakeService:
    return LakeService(settings, Storage(settings.db_file), load_lakes(settings.config_file))


def cmd_update(args, settings: Settings) -> int:
    from .notify import send_telegram
    from .pipeline import run_update

    if args.scene_cloud:
        from dataclasses import replace
        settings = replace(settings, measurement=replace(settings.measurement, scene_cloud_limit=args.scene_cloud))
    service = _service(settings)
    lakes = [l for l in service.lakes.values() if not args.lake or l.id == args.lake]
    if not lakes:
        print(f"Озеро '{args.lake}' не найдено в {settings.config_file}", file=sys.stderr)
        return 2
    result = run_update(settings, service.storage, lakes, args.start, args.end, args.workers)
    print(f"Новых измерений: {result['new_observations']}, ошибок: {result['errors']}")
    sent = send_telegram(service, args.site_url)
    if sent:
        print(f"Отправлено уведомлений: {sent}")
    return 0


def cmd_serve(args, settings: Settings) -> int:
    from .api import create_app

    app = create_app(settings)
    print(f"Сайт: http://{args.host}:{args.port}  (Ctrl+C — остановить)")
    app.run(host=args.host, port=args.port, debug=False)
    return 0


def cmd_status(args, settings: Settings) -> int:
    service = _service(settings)
    for s in service.summaries():
        cur = s["current"]["area_m2"] if s["current"] else "—"
        pct = s["change_vs_normal_pct"]
        pct_txt = f"{pct:+.0f}%" if pct is not None else "—"
        print(f"{s['level']:7} {s['status']:18} {cur:>10} м²  {pct_txt:>6}  {s['name']['ru']}")
    return 0


def cmd_import(args, settings: Settings) -> int:
    from .pipeline import import_legacy_csv

    mapping = dict(pair.split("=", 1) for pair in args.map)
    storage = Storage(settings.db_file)
    run_id = storage.start_run()
    n = import_legacy_csv(Path(args.csv), storage, mapping)
    storage.finish_run(run_id, n, 0)
    print(f"Перенесено измерений: {n}")
    return 0


def cmd_terrain(args, settings: Settings) -> int:
    from .pipeline import make_client
    from .terrain import build_terrain

    meta = build_terrain(make_client(settings), settings.frontend_dir / "assets" / "terrain")
    print(f"Карта высот сохранена: {len(meta['parts'])} частей, район {meta['bbox']}")
    return 0


def cmd_discover(args, settings: Settings) -> int:
    from .discover import discover

    r = discover(settings.config_file, settings.frontend_dir / "assets" / "terrain",
                 min_area_m2=args.min_area, min_elevation_m=args.min_elevation, dry_run=args.dry_run)
    for lake in r["added"]:
        d = lake["drainage"]
        river = (d["river"] or {}).get("ru", "—")
        print(f"+ {lake['name']['ru']} ({lake['elevation_m']} м), сток: {river}, выход: {d['exit']}")
    print(f"Добавлено озёр: {len(r['added'])}, всего в списке: {r['total']}"
          + (" (пробный запуск, файл не изменён)" if args.dry_run else ""))
    return 0


def cmd_export(args, settings: Settings) -> int:
    from .export import export_site
    from .settings import PROJECT_ROOT

    r = export_site(settings, _service(settings), Path(args.out) if args.out else PROJECT_ROOT / "dist")
    print(f"Готово: {r['out_dir']}\nФайлов: {r['files']}, озёр: {r['lakes']}, картинок: {r['previews']}, размер: {r['size_mb']} МБ")
    return 0


def cmd_notify(args, settings: Settings) -> int:
    from .notify import send_telegram

    print(f"Отправлено уведомлений: {send_telegram(_service(settings), args.site_url)}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="lakewatch", description="Мониторинг горных озёр Иле-Алатау")
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("update", help="докачать новые снимки")
    p.add_argument("--start", type=int, default=2019)
    p.add_argument("--end", type=int, default=date.today().year)
    p.add_argument("--lake", help="только одно озеро (id из config/lakes.json)")
    p.add_argument("--workers", type=int, default=6)
    p.add_argument("--scene-cloud", type=float,
                   help="брать только сцены с общей облачностью меньше этого %% (быстрее, но меньше снимков)")
    p.add_argument("--site-url", help="ссылка на сайт для уведомлений")
    p.set_defaults(func=cmd_update)

    p = sub.add_parser("serve", help="запустить сайт локально")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("status", help="состояние озёр в консоли")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("import-csv", help="перенести данные из первого прототипа")
    p.add_argument("csv")
    p.add_argument("--map", nargs="+", required=True, metavar="OLD=NEW",
                   help="соответствие старых и новых id озёр")
    p.set_defaults(func=cmd_import)

    p = sub.add_parser("terrain", help="скачать карту высот для 3D-сцены на сайте")
    p.set_defaults(func=cmd_terrain)

    p = sub.add_parser("discover", help="найти все высокогорные озёра района по OpenStreetMap и посчитать сток")
    p.add_argument("--min-area", type=float, default=1500.0, help="минимальная площадь озера, м²")
    p.add_argument("--min-elevation", type=float, default=2900.0, help="минимальная высота, м")
    p.add_argument("--dry-run", action="store_true", help="только показать, файл не менять")
    p.set_defaults(func=cmd_discover)

    p = sub.add_parser("export", help="собрать статический сайт в папку dist для публикации")
    p.add_argument("--out", help="папка сборки (по умолчанию dist в корне проекта)")
    p.set_defaults(func=cmd_export)

    p = sub.add_parser("notify", help="отправить тревоги в Telegram")
    p.add_argument("--site-url")
    p.set_defaults(func=cmd_notify)

    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO if args.verbose or args.command == "update" else logging.WARNING,
                        format="%(asctime)s %(levelname)s %(message)s")
    return args.func(args, Settings())
