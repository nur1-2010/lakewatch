"""Настройки проекта. Всё, что можно поменять без правки кода, читается из переменных окружения."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _env_path(name: str, default: Path) -> Path:
    value = os.environ.get(name)
    return Path(value).expanduser().resolve() if value else default


def _env_float(name: str, default: float) -> float:
    value = os.environ.get(name)
    return float(value) if value else default


@dataclass(frozen=True)
class MeasurementSettings:
    """Параметры измерения площади воды."""

    # Пиксель считается водой, если NDWI выше порога. При 0.0–0.1 снег и лёд у ледников
    # ошибочно попадают в «воду», поэтому выбран 0.2 (проверено на данных 2019–2026).
    ndwi_threshold: float = 0.2
    # Дополнительно сохраняем площадь при этих порогах, чтобы можно было сравнить.
    extra_thresholds: tuple[float, ...] = (0.0, 0.1, 0.2)
    # Снимок не используется, если облаков/теней над озером больше (в %).
    max_cloud_pct: float = 15.0
    # ...или снега больше (озеро может быть засыпано или замёрзнуть).
    max_snow_pct: float = 40.0
    # Грубый фильтр облачности всей сцены (100×100 км) при поиске снимков.
    scene_cloud_limit: float = 70.0
    # Месяцы, когда озёра свободны ото льда.
    months: tuple[int, ...] = (7, 8, 9)


@dataclass(frozen=True)
class AnalysisSettings:
    """Пороги, по которым определяется состояние озера."""

    min_observations: int = 8          # меньше — «недостаточно данных»
    min_years: int = 3
    min_obs_per_year: int = 3          # год с меньшим числом снимков не участвует в сравнениях
    recent_window: int = 3             # «текущая площадь» = медиана последних N снимков
    rapid_rise_pct: float = 30.0       # «быстрый рост»: на столько % больше нормы...
    rapid_rise_min_m2: float = 3000.0  # ...и хотя бы на столько м² (30 пикселей снимка)
    rapid_rise_over_max_pct: float = 5.0   # ...и выше максимума всех прошлых лет на столько %
    min_status_change_m2: float = 2000.0   # меньшее изменение не отличить от шума измерений
    rise_with_trend_pct: float = 5.0   # при устойчивом тренде достаточно такого превышения нормы
    publish_min_area_m2: float = 2000.0    # озёра мельче (20 пикселей) на сайте не показываются
    rise_pct: float = 12.0             # «наблюдается рост»
    fall_pct: float = -15.0            # «наблюдается уменьшение»
    trend_pct_per_year: float = 5.0    # заметный многолетний тренд, % в год
    new_lake_max_initial_m2: float = 500.0   # в первый год воды почти не было...
    new_lake_min_current_m2: float = 1000.0  # ...а сейчас есть
    season_change_pct: float = 10.0    # заметное изменение внутри сезона
    yoy_change_pct: float = 5.0        # заметное изменение к прошлому году
    streak_step_pct: float = 3.0       # минимальный шаг, чтобы год считался «ростом» в серии
    stale_days: int = 45               # данные старше — объясняем, почему нет свежих


@dataclass(frozen=True)
class Settings:
    config_file: Path = field(default_factory=lambda: _env_path(
        "LAKEWATCH_CONFIG", PROJECT_ROOT / "config" / "lakes.json"))
    data_dir: Path = field(default_factory=lambda: _env_path(
        "LAKEWATCH_DATA_DIR", PROJECT_ROOT / "data"))
    frontend_dir: Path = field(default_factory=lambda: _env_path(
        "LAKEWATCH_FRONTEND_DIR", PROJECT_ROOT / "frontend"))
    stac_url: str = os.environ.get(
        "LAKEWATCH_STAC_URL", "https://planetarycomputer.microsoft.com/api/stac/v1/search")
    data_api_url: str = os.environ.get(
        "LAKEWATCH_DATA_API_URL", "https://planetarycomputer.microsoft.com/api/data/v1")
    collection: str = "sentinel-2-l2a"
    http_timeout_s: float = _env_float("LAKEWATCH_HTTP_TIMEOUT", 180.0)
    telegram_bot_token: str | None = os.environ.get("TELEGRAM_BOT_TOKEN")
    telegram_chat_id: str | None = os.environ.get("TELEGRAM_CHAT_ID")
    measurement: MeasurementSettings = field(default_factory=MeasurementSettings)
    analysis: AnalysisSettings = field(default_factory=AnalysisSettings)

    @property
    def db_file(self) -> Path:
        return self.data_dir / "lakewatch.sqlite3"

    @property
    def previews_dir(self) -> Path:
        return self.data_dir / "previews"
