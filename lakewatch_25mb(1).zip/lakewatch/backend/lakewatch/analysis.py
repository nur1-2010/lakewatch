"""Анализ рядов измерений: состояние озера и подробные выводы.

Результат не зависит от языка: выводы — это ключи сообщений с параметрами
(например {"key": "trend.up", "params": {...}}), а сайт переводит их на русский,
казахский или английский.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass
from datetime import date

from .measure import Observation
from .settings import AnalysisSettings, MeasurementSettings

SMALL_LAKE_M2 = 5000.0      # меньше ~50 пикселей: точность заметно ниже
# Эмпирическая связь объёма (м³) и площади (м²) ледниковых озёр: V = 0.104 · A^1.42
# (Huggel et al., 2002). Даёт только порядок величины — ошибка может быть в разы.
HUGGEL_K, HUGGEL_POWER = 0.104, 1.42
VOLUME_MIN_AREA_M2 = 1000.0

STATUS_LEVEL = {
    "rapid_rise": "alert",
    "new_lake": "watch",
    "rising": "watch",
    "falling": "info",
    "stable": "normal",
    "insufficient_data": "info",
}


@dataclass(frozen=True)
class Point:
    date: str
    area_m2: float
    scl_water_m2: float
    cloud_pct: float
    item_id: str

    @property
    def year(self) -> int:
        return int(self.date[:4])


def valid_points(observations: list[Observation], m: MeasurementSettings) -> list[Point]:
    """Годные измерения, по одному на дату (если снимков за день два — менее облачный)."""
    best: dict[str, Observation] = {}
    for o in observations:
        if not o.is_valid(m):
            continue
        if o.date not in best or o.cloud_pct < best[o.date].cloud_pct:
            best[o.date] = o
    pts = []
    for d in sorted(best):
        o = best[d]
        area = o.area_m2.get(m.ndwi_threshold)
        if area is None:
            continue
        pts.append(Point(d, float(area), o.scl_water_m2, o.cloud_pct, o.item_id))
    return pts


def yearly_medians(points: list[Point]) -> dict[int, float]:
    by_year: dict[int, list[float]] = {}
    for p in points:
        by_year.setdefault(p.year, []).append(p.area_m2)
    return {y: statistics.median(v) for y, v in sorted(by_year.items())}


def _yearly_rows(points: list[Point], yearly: dict[int, float]) -> list[dict]:
    """Строки таблицы по годам: медиана, число снимков, изменение к предыдущему году."""
    counts: dict[int, int] = {}
    for p in points:
        counts[p.year] = counts.get(p.year, 0) + 1
    rows, prev = [], None
    for y, v in yearly.items():
        rows.append({"year": y, "median_area_m2": round(v), "observations": counts.get(y, 0),
                     "change_pct": None if prev is None else _r(_pct(v, prev), 1),
                     "change_m2": None if prev is None else round(v - prev)})
        prev = v
    return rows


def theil_sen_slope(xs: list[float], ys: list[float]) -> float | None:
    """Устойчивый к выбросам наклон: медиана наклонов по всем парам точек."""
    slopes = [(ys[j] - ys[i]) / (xs[j] - xs[i])
              for i in range(len(xs)) for j in range(i + 1, len(xs)) if xs[j] != xs[i]]
    return statistics.median(slopes) if slopes else None


def _pct(new: float, base: float) -> float | None:
    return None if base < 1 else 100.0 * (new / base - 1.0)


def _r(x: float | None, nd: int = 0) -> float | None:
    return None if x is None else round(x, nd)


def analyze(observations: list[Observation], m: MeasurementSettings, a: AnalysisSettings,
            role: str = "monitored", today: date | None = None) -> dict:
    today = today or date.today()
    points = valid_points(observations, m)
    # Год с одним-двумя снимками ненадёжен (озеро могло быть подо льдом или в тени):
    # такие годы в сравнения не берём, чтобы не получать ложные «рост в 30 раз».
    per_year: dict[int, int] = {}
    for p in points:
        per_year[p.year] = per_year.get(p.year, 0) + 1
    points = [p for p in points if per_year[p.year] >= a.min_obs_per_year]
    yearly = yearly_medians(points)
    findings: list[dict] = []

    result: dict = {
        "observations_total": len({o.date for o in observations}),
        "observations_valid": len(points),
        "years": list(yearly),
        "yearly": _yearly_rows(points, yearly),
        "current": None, "normal": None, "change_vs_normal_pct": None, "change_vs_normal_m2": None,
        "trend": None, "season": None, "new_lake": None, "record": None,
        "year_over_year": None, "since_start": None, "streak": None, "rank": None,
        "seasonality": None, "volume_estimate": None, "meaning": None,
    }

    if len(points) < a.min_observations or len(yearly) < a.min_years:
        result.update(status="insufficient_data", level=STATUS_LEVEL["insufficient_data"])
        findings.append({"key": "headline.insufficient",
                         "params": {"count": len(points), "years": len(yearly)}})
        result["findings"] = findings + _data_notes(points, m, a, today)
        return result

    last = points[-1]
    current_year = last.year
    season_pts = [p for p in points if p.year == current_year]
    # «Текущая площадь» — медиана всего последнего сезона, а не последних снимков:
    # в конце сентября озёра начинают замерзать, и сравнение с нормой за все летние
    # месяцы было бы нечестным. Если в сезоне мало снимков — берём последние N.
    basis = season_pts if len(season_pts) >= a.recent_window + 1 else points[-a.recent_window:]
    current_area = statistics.median(p.area_m2 for p in basis)
    past = [p.area_m2 for p in points if p.year < current_year]
    normal = statistics.median(past) if past else None
    past_years = [y for y in yearly if y < current_year]

    result["current"] = {"area_m2": round(current_area), "year": current_year,
                         "observations": len(basis), "basis": "season" if basis is season_pts else "recent",
                         "last_date": last.date, "last_area_m2": round(last.area_m2)}
    if normal is not None:
        result["normal"] = {"area_m2": round(normal), "year_from": past_years[0], "year_to": past_years[-1]}
        result["change_vs_normal_m2"] = round(current_area - normal)
        result["change_vs_normal_pct"] = _r(_pct(current_area, normal), 1)
    change_pct = result["change_vs_normal_pct"]

    # --- многолетний тренд по медианам за годы
    years, medians = list(yearly), list(yearly.values())
    slope = theil_sen_slope([float(y) for y in years], medians)
    mean_area = statistics.mean(medians)
    trend_pct = None if slope is None or mean_area < 1 else 100 * slope / mean_area
    if slope is not None:
        direction = ("up" if trend_pct is not None and trend_pct >= a.trend_pct_per_year else
                     "down" if trend_pct is not None and trend_pct <= -a.trend_pct_per_year else "flat")
        result["trend"] = {"m2_per_year": round(slope), "pct_per_year": _r(trend_pct, 1),
                           "direction": direction, "year_from": years[0], "year_to": years[-1]}

    # --- изменение внутри текущего сезона
    if len(season_pts) >= 4:
        k = min(3, len(season_pts) // 2)
        start = statistics.median(p.area_m2 for p in season_pts[:k])
        end = statistics.median(p.area_m2 for p in season_pts[-k:])
        s_pct = _pct(end, start)
        s_dir = ("up" if s_pct is not None and s_pct >= a.season_change_pct else
                 "down" if s_pct is not None and s_pct <= -a.season_change_pct else "flat")
        result["season"] = {"year": current_year, "start_area_m2": round(start), "start_date": season_pts[0].date,
                            "end_area_m2": round(end), "end_date": season_pts[-1].date,
                            "change_pct": _r(s_pct, 1), "direction": s_dir}

    # --- новое озеро: в первый год воды почти не было
    first_year, first_area = years[0], medians[0]
    is_new = first_area <= a.new_lake_max_initial_m2 and current_area >= a.new_lake_min_current_m2
    if is_new:
        appeared = next((y for y, v in yearly.items() if v > a.new_lake_max_initial_m2), current_year)
        result["new_lake"] = {"first_year": first_year, "first_area_m2": round(first_area),
                              "appeared_year": appeared}

    # --- рекорд
    max_year = max(yearly, key=yearly.get)
    result["record"] = {"year": max_year, "median_area_m2": round(yearly[max_year]),
                        "is_current_year": max_year == current_year}

    # --- сравнение с прошлым годом
    if past_years:
        prev_year, prev_area = past_years[-1], yearly[past_years[-1]]
        y_pct = _pct(current_area, prev_area)
        y_dir = ("flat" if y_pct is None else "up" if y_pct >= a.yoy_change_pct else
                 "down" if y_pct <= -a.yoy_change_pct else "flat")
        result["year_over_year"] = {"year": current_year, "prev_year": prev_year,
                                    "prev_area_m2": round(prev_area), "area_m2": round(current_area),
                                    "change_m2": round(current_area - prev_area),
                                    "change_pct": _r(y_pct, 1), "direction": y_dir}

    # --- сравнение с первым годом наблюдений
    result["since_start"] = {"year": years[0], "area_m2": round(medians[0]),
                             "change_m2": round(current_area - medians[0]),
                             "change_pct": _r(_pct(current_area, medians[0]), 1)}

    # --- сколько лет подряд площадь растёт или уменьшается
    streak_dir, streak_len = None, 0
    for prev, cur in zip(reversed(medians[:-1]), reversed(medians[1:])):
        step = _pct(cur, prev)
        d = None if step is None else "up" if step >= a.streak_step_pct else "down" if step <= -a.streak_step_pct else None
        if d is None or (streak_dir and d != streak_dir):
            break
        streak_dir, streak_len = d, streak_len + 1
    if streak_len >= 2:
        result["streak"] = {"direction": streak_dir, "years": streak_len, "since_year": years[-1 - streak_len]}

    # --- место текущего года среди всех лет (1 — самая большая площадь)
    ordered = sorted(yearly, key=yearly.get, reverse=True)
    result["rank"] = {"year": current_year, "position": ordered.index(current_year) + 1, "total": len(ordered)}

    # --- в каком месяце озеро обычно больше всего
    by_month: dict[int, list[float]] = {}
    for p in points:
        by_month.setdefault(int(p.date[5:7]), []).append(p.area_m2)
    month_medians = {mth: statistics.median(v) for mth, v in by_month.items() if len(v) >= 5}
    if len(month_medians) >= 2:
        peak = max(month_medians, key=month_medians.get)
        low = min(month_medians, key=month_medians.get)
        if month_medians[low] >= 1 and month_medians[peak] / month_medians[low] >= 1.1:
            result["seasonality"] = {"peak_month": peak, "peak_area_m2": round(month_medians[peak]),
                                     "low_month": low, "low_area_m2": round(month_medians[low])}

    # --- грубая оценка объёма воды по площади: V = 0.104 · A^1.42 (Huggel et al., 2002)
    if role != "reference" and current_area >= VOLUME_MIN_AREA_M2:
        result["volume_estimate"] = {"m3": round(HUGGEL_K * current_area ** HUGGEL_POWER, -2),
                                     "method": "huggel2002"}

    # --- итоговое состояние
    # Правила намеренно строгие: у маленького озера площадь «скачет» на 10–20% просто из-за
    # разрешения спутника (10 м), поэтому изменение должно быть заметным и в процентах, и в м².
    abs_change = result["change_vs_normal_m2"] or 0
    past_max = max((yearly[y] for y in past_years), default=0.0)
    big_enough = abs(abs_change) >= a.min_status_change_m2
    if is_new:
        status = "new_lake"
    elif (change_pct is not None and change_pct >= a.rapid_rise_pct and abs_change >= a.rapid_rise_min_m2
          and current_area >= past_max * (1 + a.rapid_rise_over_max_pct / 100)):
        # «быстрый рост» — только если площадь ещё и выше максимума всех прошлых лет;
        # иначе это может быть просто возврат к обычному размеру после маловодного года
        status = "rapid_rise"
    elif change_pct is not None and (
            (change_pct >= a.rise_pct and big_enough) or
            (trend_pct is not None and trend_pct >= a.trend_pct_per_year and change_pct >= a.rise_with_trend_pct
             and current_area - medians[0] >= a.min_status_change_m2)):
        status = "rising"
    elif change_pct is not None and change_pct <= a.fall_pct and big_enough:
        status = "falling"
    else:
        status = "stable"
    result["max_yearly_m2"] = round(max(medians))
    result["status"] = status
    result["level"] = STATUS_LEVEL[status]

    # --- подробные выводы, от главного к деталям
    cur, nor = round(current_area), (round(normal) if normal is not None else None)
    if status == "new_lake":
        findings.append({"key": "headline.new_lake", "params": {
            "first_year": first_year, "appeared_year": result["new_lake"]["appeared_year"], "area": cur}})
    elif status in ("rapid_rise", "rising", "falling"):
        findings.append({"key": f"headline.{status}", "params": {
            "pct": abs(round(change_pct)), "area": cur, "normal": nor,
            "year_from": past_years[0], "year_to": past_years[-1]}})
    else:
        findings.append({"key": "headline.stable", "params": {
            "pct": abs(round(change_pct or 0)), "area": cur, "normal": nor}})

    if role == "reference":
        findings.append({"key": "note.reference", "params": {}})
    else:
        result["meaning"] = f"meaning.{status}"

    yoy = result["year_over_year"]
    if yoy and yoy["change_pct"] is not None:
        findings.append({"key": f"yoy.{yoy['direction']}", "params": {
            "year": yoy["year"], "prev_year": yoy["prev_year"], "from": yoy["prev_area_m2"],
            "to": yoy["area_m2"], "pct": abs(round(yoy["change_pct"]))}})

    if result["streak"]:
        s = result["streak"]
        findings.append({"key": f"streak.{s['direction']}", "params": {
            "count": s["years"], "since_year": s["since_year"]}})

    # Если в последний год воды не осталось (медиана 0), отношение посчитать нельзя: 1 / 0.
    # Раньше здесь было деление на ноль, из-за которого падал весь сайт.
    ratio = medians[-1] / medians[0] if medians[0] >= 1 and medians[-1] >= 1 else None
    if medians[0] >= 1 and medians[-1] < 1:
        findings.append({"key": "multi_year.gone", "params": {
            "first_year": years[0], "first_area": round(medians[0]), "last_year": years[-1]}})
    if ratio is not None and (ratio >= 1.5 or ratio <= 0.67) and not is_new:
        findings.append({"key": "multi_year.grew" if ratio > 1 else "multi_year.shrank", "params": {
            "first_year": years[0], "first_area": round(medians[0]),
            "last_year": years[-1], "last_area": round(medians[-1]), "ratio": round(ratio if ratio > 1 else 1 / ratio, 1)}})

    if result["trend"]:
        t = result["trend"]
        findings.append({"key": f"trend.{t['direction']}", "params": {
            "rate": abs(t["m2_per_year"]), "pct": abs(t["pct_per_year"] or 0),
            "year_from": t["year_from"], "year_to": t["year_to"]}})

    if result["season"]:
        s = result["season"]
        findings.append({"key": f"season.{s['direction']}", "params": {
            "year": s["year"], "from": s["start_area_m2"], "to": s["end_area_m2"],
            "date_from": s["start_date"], "date_to": s["end_date"], "pct": abs(round(s["change_pct"] or 0))}})

    if result["record"]["is_current_year"] and len(yearly) >= 3 and status != "new_lake":
        findings.append({"key": "record.max_now", "params": {"year": max_year, "area": result["record"]["median_area_m2"]}})
    elif len(yearly) >= 3 and status != "new_lake":
        findings.append({"key": "rank.position", "params": {
            "year": current_year, "rank": result["rank"]["position"], "total": result["rank"]["total"],
            "record_year": max_year, "area": result["record"]["median_area_m2"]}})

    if result["seasonality"]:
        sn = result["seasonality"]
        findings.append({"key": "seasonality.peak", "params": {
            "month": sn["peak_month"], "area": sn["peak_area_m2"],
            "low_month": sn["low_month"], "normal": sn["low_area_m2"]}})

    if result["volume_estimate"]:
        findings.append({"key": "volume.estimate", "params": {"volume": result["volume_estimate"]["m3"]}})

    result["findings"] = findings + _data_notes(points, m, a, today)
    return result


def _data_notes(points: list[Point], m: MeasurementSettings, a: AnalysisSettings, today: date) -> list[dict]:
    notes = []
    if points:
        last = date.fromisoformat(points[-1].date)
        days = (today - last).days
        if days > a.stale_days:
            key = "data.off_season" if today.month not in m.months else "data.no_recent"
            notes.append({"key": key, "params": {"date": points[-1].date, "days": days}})
        cur = statistics.median(p.area_m2 for p in points[-3:])
        if 0 < cur < SMALL_LAKE_M2:
            pix = round(cur / 100)
            notes.append({"key": "data.small_lake", "params": {"pixels": pix}})
    return notes


def chart_series(observations: list[Observation], m: MeasurementSettings) -> list[dict]:
    """Все измерения для графика, включая отброшенные (с причиной)."""
    out = []
    for o in sorted(observations, key=lambda o: (o.date, o.item_id)):
        reason = None
        if o.cloud_pct > m.max_cloud_pct:
            reason = "clouds"
        elif o.snow_pct > m.max_snow_pct:
            reason = "snow"
        out.append({"date": o.date, "area_m2": round(o.area_m2.get(m.ndwi_threshold, 0)),
                    "scl_water_m2": round(o.scl_water_m2), "cloud_pct": o.cloud_pct,
                    "snow_pct": o.snow_pct, "valid": reason is None, "rejected_reason": reason})
    return out
