"""Сводка по озёрам для сайта и уведомлений (с кэшем, чтобы не пересчитывать на каждый запрос)."""

from __future__ import annotations

import threading
from datetime import date

from .analysis import analyze, chart_series, valid_points
from .lakes import Lake
from .pipeline import PREVIEW_FRAME_SCALE, PREVIEW_SUFFIX
from .settings import Settings
from .storage import Storage


class LakeService:
    def __init__(self, settings: Settings, storage: Storage, lakes: list[Lake]):
        self.settings = settings
        self.storage = storage
        self.lakes = {lake.id: lake for lake in lakes}
        self._cache: dict = {}
        self._cache_key: tuple | None = None
        self._lock = threading.Lock()

    def _fresh_cache(self) -> dict:
        key = (self.storage.data_version(), date.today().isoformat())
        with self._lock:
            if key != self._cache_key:
                self._cache, self._cache_key = {}, key
            return self._cache

    def analysis(self, lake_id: str) -> dict:
        cache = self._fresh_cache()
        if lake_id not in cache:
            lake = self.lakes[lake_id]
            cache[lake_id] = analyze(self.storage.observations(lake_id), self.settings.measurement,
                                     self.settings.analysis, role=lake.role)
        return cache[lake_id]

    def published(self, lake_id: str) -> bool:
        """Показывать ли озеро на сайте.

        Озёра, найденные автоматически, публикуются только если спутник их действительно «видит»:
        хотя бы в один год медиана площади не меньше порога (20 пикселей снимка). Иначе цифры по ним —
        шум, и писать про такое озеро нечего. Озёра, добавленные вручную, показываются всегда.
        """
        lake = self.lakes[lake_id]
        if not lake.auto:
            return True
        a = self.analysis(lake_id)
        return a["status"] != "insufficient_data" and \
            (a.get("max_yearly_m2") or 0) >= self.settings.analysis.publish_min_area_m2

    def summary(self, lake_id: str) -> dict:
        lake, a = self.lakes[lake_id], self.analysis(lake_id)
        previews = [p for p in self.storage.previews(lake_id) if PREVIEW_SUFFIX in p["file_name"]]
        return {
            **lake.to_public_dict(),
            "preview": f"previews/{previews[-1]['file_name']}" if previews else None,
            "status": a["status"], "level": a["level"],
            "current": a["current"], "normal": a["normal"],
            "change_vs_normal_pct": a["change_vs_normal_pct"],
            "year_over_year": a["year_over_year"],
            "yearly": [{"year": y["year"], "median_area_m2": y["median_area_m2"]} for y in a["yearly"]],
            "headline": a["findings"][0] if a["findings"] else None,
        }

    def overview(self) -> dict:
        """Общая картина по всем наблюдаемым озёрам (контрольное не учитывается)."""
        monitored = [(lake, self.analysis(lake.id)) for lake in self.lakes.values()
                     if lake.role != "reference" and self.published(lake.id)]
        by_status: dict[str, int] = {}
        for _, a in monitored:
            by_status[a["status"]] = by_status.get(a["status"], 0) + 1
        years = sorted({y for _, a in monitored for y in a["years"]})
        total = None
        pairs = [a["year_over_year"] for _, a in monitored if a["year_over_year"]]
        if pairs:
            # сравниваем одну и ту же пару лет у всех озёр: берём самую частую (обычно последний сезон)
            counts: dict[tuple, int] = {}
            for p in pairs:
                counts[(p["year"], p["prev_year"])] = counts.get((p["year"], p["prev_year"]), 0) + 1
            best = max(counts, key=lambda k: (counts[k], k))
            pairs = [p for p in pairs if (p["year"], p["prev_year"]) == best]
            cur, prev = sum(p["area_m2"] for p in pairs), sum(p["prev_area_m2"] for p in pairs)
            pct = None if prev < 1 else round(100 * (cur / prev - 1), 1)
            total = {"year": pairs[0]["year"], "prev_year": pairs[0]["prev_year"], "area_m2": cur,
                     "prev_area_m2": prev, "change_pct": pct, "lakes": len(pairs),
                     "direction": "flat" if pct is None or abs(pct) < 5 else "up" if pct > 0 else "down"}
        n, _ = self.storage.data_version()
        return {
            "lakes_monitored": len(monitored),
            "lakes_attention": sum(1 for _, a in monitored if a["level"] in ("alert", "watch")),
            "by_status": by_status,
            "lakes_hidden": sum(1 for i in self.lakes if not self.published(i)),
            "lakes_with_data": sum(1 for _, a in monitored if a["status"] != "insufficient_data"),
            "to_almaty": sum(1 for lake, _ in monitored if (lake.drainage or {}).get("downstream") == "almaty"),
            "to_talgar": sum(1 for lake, _ in monitored if (lake.drainage or {}).get("downstream") == "talgar"),
            "observations": n,
            "year_from": years[0] if years else None, "year_to": years[-1] if years else None,
            "total_area": total,
        }

    def summaries(self) -> list[dict]:
        order = {"alert": 0, "watch": 1, "normal": 2, "info": 3}
        towns = {"almaty": 0, "talgar": 1}
        items = [self.summary(i) for i in self.lakes if self.published(i)]
        # сначала тревожные, затем те, что стекают к городам, затем по площади; контрольное — в конце
        return sorted(items, key=lambda s: (
            s["role"] == "reference", order.get(s["level"], 9),
            towns.get((s.get("drainage") or {}).get("downstream"), 2),
            -(s["current"]["area_m2"] if s["current"] else 0)))

    def detail(self, lake_id: str) -> dict:
        lake = self.lakes[lake_id]
        observations = self.storage.observations(lake_id)
        return {
            "lake": lake.to_public_dict(),
            "analysis": self.analysis(lake_id),
            "series": chart_series(observations, self.settings.measurement),
            # относительный путь — сайт будет работать и в подпапке, например example.org/lakewatch/
            "previews": [{"date": p["date"], "url": f"previews/{p['file_name']}"}
                         for p in self.storage.previews(lake_id) if PREVIEW_SUFFIX in p["file_name"]],
            "preview_frame_scale": PREVIEW_FRAME_SCALE,
        }

    def alerts(self) -> list[dict]:
        return [s for s in self.summaries() if s["level"] in ("alert", "watch") and s["role"] != "reference"]

    def valid_points(self, lake_id: str):
        return valid_points(self.storage.observations(lake_id), self.settings.measurement)

    def meta(self) -> dict:
        m = self.settings.measurement
        n, _ = self.storage.data_version()
        return {
            "last_run": self.storage.last_run(),
            "observations": n,
            "method": {"ndwi_threshold": m.ndwi_threshold, "max_cloud_pct": m.max_cloud_pct,
                       "max_snow_pct": m.max_snow_pct, "months": list(m.months),
                       "pixel_size_m": 10, "satellite": "Sentinel-2 L2A"},
            "sources": [
                {"name": "Copernicus Sentinel-2 (ESA)", "url": "https://dataspace.copernicus.eu/"},
                {"name": "Microsoft Planetary Computer", "url": "https://planetarycomputer.microsoft.com/"},
                {"name": "OpenStreetMap", "url": "https://www.openstreetmap.org/copyright"},
            ],
        }
