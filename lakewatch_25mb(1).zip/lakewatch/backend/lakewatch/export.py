"""Сборка сайта в папку готовых файлов (статический сайт).

Зачем: у статического сайта нет сервера с программой, базы данных, паролей и админки —
значит, нечего взламывать. Хостинг просто отдаёт файлы. Данные обновляются так:
на своём компьютере запускаем `update`, затем `export` и выкладываем папку заново.

В папку попадают: страницы и скрипты сайта, данные в виде .json, таблицы .csv,
спутниковые картинки и файл `_headers` с защитными заголовками (его понимают
Netlify и Cloudflare Pages). База данных и настройки в сборку НЕ попадают.
"""

from __future__ import annotations

import csv
import io
import json
import shutil
from pathlib import Path

from .service import LakeService
from .settings import Settings

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
       "font-src https://fonts.gstatic.com; img-src 'self' data: blob: https://server.arcgisonline.com; "
       "connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'none'; frame-ancestors 'none'")

HEADERS = f"""/*
  Content-Security-Policy: {CSP}
  X-Frame-Options: DENY
  X-Content-Type-Options: nosniff
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: geolocation=(), camera=(), microphone=(), payment=(), usb=()
  Strict-Transport-Security: max-age=31536000; includeSubDomains
  Cross-Origin-Opener-Policy: same-origin

/api/*
  Access-Control-Allow-Origin: *
  Cache-Control: public, max-age=300

/previews/*
  Cache-Control: public, max-age=604800

/vendor/*
  Cache-Control: public, max-age=604800
"""

CSV_FIELDS = ["date", "area_m2", "scl_water_m2", "cloud_pct", "snow_pct", "valid", "rejected_reason"]


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")


def export_site(settings: Settings, service: LakeService, out_dir: Path) -> dict:
    out_dir = out_dir.resolve()
    project = settings.frontend_dir.resolve().parent
    # защита от опечатки: не даём стереть что-то важное вместо папки сборки
    if out_dir in (project, settings.frontend_dir.resolve(), settings.data_dir.resolve()) or project not in out_dir.parents:
        raise ValueError(f"Папка сборки должна быть внутри проекта и не совпадать с его рабочими папками: {out_dir}")
    if out_dir.exists():
        shutil.rmtree(out_dir)
    shutil.copytree(settings.frontend_dir, out_dir)

    api = out_dir / "api"
    summaries = service.summaries()
    _write_json(api / "lakes.json", {"lakes": summaries})
    _write_json(api / "meta.json", service.meta())
    _write_json(api / "overview.json", service.overview())
    _write_json(api / "alerts.json", {"alerts": service.alerts()})
    _write_json(api / "health.json", {"status": "ok", "static": True})

    used_previews: set[str] = set()
    published = [lake_id for lake_id in service.lakes if service.published(lake_id)]
    for lake_id in published:      # скрытые озёра (слишком малы для измерений) в сборку не попадают
        detail = service.detail(lake_id)
        _write_json(api / "lakes" / f"{lake_id}.json", detail)
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=CSV_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(detail["series"])
        csv_path = api / "lakes" / lake_id / "observations.csv"
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        csv_path.write_text(buf.getvalue(), encoding="utf-8")
        used_previews.update(Path(p["url"]).name for p in detail["previews"])

    previews = out_dir / "previews"
    previews.mkdir(exist_ok=True)
    copied = 0
    for name in sorted(used_previews):
        src = settings.previews_dir / name
        if src.exists():
            shutil.copy2(src, previews / name)
            copied += 1

    (out_dir / "_headers").write_text(HEADERS, encoding="utf-8")
    (out_dir / ".nojekyll").write_text("", encoding="utf-8")          # для GitHub Pages
    (out_dir / "robots.txt").write_text("User-agent: *\nAllow: /\n", encoding="utf-8")
    (out_dir / "404.html").write_text(
        '<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=/">'
        "<title>LakeWatch</title><p><a href=\"/\">LakeWatch</a></p>", encoding="utf-8")

    files = [p for p in out_dir.rglob("*") if p.is_file()]
    return {"out_dir": str(out_dir), "files": len(files), "lakes": len(published), "previews": copied,
            "size_mb": round(sum(p.stat().st_size for p in files) / 1e6, 1)}
