"""Хранение измерений в SQLite (входит в стандартную библиотеку Python)."""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterator

from .measure import Observation

SCHEMA = """
CREATE TABLE IF NOT EXISTS observations (
    lake_id       TEXT NOT NULL,
    item_id       TEXT NOT NULL,
    date          TEXT NOT NULL,
    box_pixels    INTEGER NOT NULL,
    pixel_m2      REAL NOT NULL,
    cloud_pct     REAL NOT NULL,
    snow_pct      REAL NOT NULL,
    scl_water_m2  REAL NOT NULL,
    areas_json    TEXT NOT NULL,           -- {"0.2": площадь, ...}
    created_at    TEXT NOT NULL,
    PRIMARY KEY (lake_id, item_id)
);
CREATE INDEX IF NOT EXISTS idx_observations_lake_date ON observations (lake_id, date);

CREATE TABLE IF NOT EXISTS runs (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at        TEXT NOT NULL,
    finished_at       TEXT,
    new_observations  INTEGER NOT NULL DEFAULT 0,
    errors            INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS previews (
    lake_id   TEXT NOT NULL,
    date      TEXT NOT NULL,
    item_id   TEXT NOT NULL,
    file_name TEXT NOT NULL,
    PRIMARY KEY (lake_id, date)
);

CREATE TABLE IF NOT EXISTS notifications (
    lake_id      TEXT PRIMARY KEY,
    status       TEXT NOT NULL,
    notified_at  TEXT NOT NULL
);
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class Storage:
    def __init__(self, db_file: Path):
        self.db_file = db_file
        db_file.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as conn:
            conn.executescript(SCHEMA)

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.db_file, timeout=30)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")   # сайт может читать, пока идёт обновление
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    # ------------------------------------------------------------ измерения

    def known_item_ids(self, lake_id: str) -> set[str]:
        with self.connect() as conn:
            rows = conn.execute("SELECT item_id FROM observations WHERE lake_id = ?", (lake_id,))
            return {r["item_id"] for r in rows}

    def save_observations(self, observations: list[Observation]) -> None:
        if not observations:
            return
        now = utc_now()
        with self.connect() as conn:
            conn.executemany(
                """INSERT OR REPLACE INTO observations
                   (lake_id, item_id, date, box_pixels, pixel_m2, cloud_pct, snow_pct,
                    scl_water_m2, areas_json, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                [(o.lake_id, o.item_id, o.date, o.box_pixels, o.pixel_m2, o.cloud_pct, o.snow_pct,
                  o.scl_water_m2, json.dumps({str(k): v for k, v in o.area_m2.items()}), now)
                 for o in observations])

    def observations(self, lake_id: str) -> list[Observation]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT * FROM observations WHERE lake_id = ? ORDER BY date, item_id", (lake_id,))
            return [Observation(
                lake_id=r["lake_id"], item_id=r["item_id"], date=r["date"],
                box_pixels=r["box_pixels"], pixel_m2=r["pixel_m2"], cloud_pct=r["cloud_pct"],
                snow_pct=r["snow_pct"], scl_water_m2=r["scl_water_m2"],
                area_m2={float(k): v for k, v in json.loads(r["areas_json"]).items()},
            ) for r in rows]

    def data_version(self) -> tuple[int, str]:
        """Меняется при любом новом измерении — по нему сбрасывается кэш анализа."""
        with self.connect() as conn:
            r = conn.execute("SELECT COUNT(*) AS n, MAX(created_at) AS t FROM observations").fetchone()
            return int(r["n"]), r["t"] or ""

    # ------------------------------------------------------------ запуски обновления

    def start_run(self) -> int:
        with self.connect() as conn:
            return int(conn.execute("INSERT INTO runs (started_at) VALUES (?)", (utc_now(),)).lastrowid)

    def finish_run(self, run_id: int, new_observations: int, errors: int) -> None:
        with self.connect() as conn:
            conn.execute("UPDATE runs SET finished_at = ?, new_observations = ?, errors = ? WHERE id = ?",
                         (utc_now(), new_observations, errors, run_id))

    def last_run(self) -> dict | None:
        with self.connect() as conn:
            r = conn.execute("SELECT * FROM runs WHERE finished_at IS NOT NULL ORDER BY id DESC LIMIT 1").fetchone()
            return dict(r) if r else None

    # ------------------------------------------------------------ картинки

    def save_preview(self, lake_id: str, date: str, item_id: str, file_name: str) -> None:
        with self.connect() as conn:
            conn.execute("INSERT OR REPLACE INTO previews VALUES (?, ?, ?, ?)", (lake_id, date, item_id, file_name))

    def previews(self, lake_id: str) -> list[dict]:
        with self.connect() as conn:
            rows = conn.execute("SELECT * FROM previews WHERE lake_id = ? ORDER BY date", (lake_id,))
            return [dict(r) for r in rows]

    # ------------------------------------------------------------ уведомления

    def last_notified_status(self, lake_id: str) -> str | None:
        with self.connect() as conn:
            r = conn.execute("SELECT status FROM notifications WHERE lake_id = ?", (lake_id,)).fetchone()
            return r["status"] if r else None

    def set_notified_status(self, lake_id: str, status: str) -> None:
        with self.connect() as conn:
            conn.execute("INSERT OR REPLACE INTO notifications VALUES (?, ?, ?)", (lake_id, status, utc_now()))
