"""Карта высот района для 3D-сцены на сайте.

Источник — цифровая модель рельефа Copernicus DEM (30 м) через Microsoft Planetary Computer.
Модель хранится плитками 1°×1°, а наш район лежит на стыке четырёх плиток, поэтому
скачиваем по кусочку из каждой; сайт сам склеивает их на холсте.

Высота кодируется яркостью пикселя: 0 = elev_min, 255 = elev_max.
"""

from __future__ import annotations

import json
import math
import urllib.parse
from pathlib import Path

from .sentinel import SentinelClient

DEM_COLLECTION = "cop-dem-glo-30"
# Район: от Большого Алматинского озера на западе до ледников у пика СГУ на востоке
TERRAIN_BBOX = (76.93, 42.955, 77.19, 43.135)      # мин. долгота, мин. широта, макс. долгота, макс. широта
ELEV_MIN, ELEV_MAX = 1400, 4700                    # метры: дно долин и чуть выше самых высоких пиков
PIXELS_PER_DEGREE = 1100                           # ~100 м на пиксель: достаточно для 3D-сцены


def _tile_id(lat: int, lon: int) -> str:
    ns, ew = ("N" if lat >= 0 else "S"), ("E" if lon >= 0 else "W")
    return f"Copernicus_DSM_COG_10_{ns}{abs(lat):02d}_00_{ew}{abs(lon):03d}_00_DEM"


def build_terrain(client: SentinelClient, out_dir: Path, bbox=TERRAIN_BBOX) -> dict:
    out_dir.mkdir(parents=True, exist_ok=True)
    x0, y0, x1, y1 = bbox
    parts = []
    for lat in range(math.floor(y0), math.floor(y1) + 1):
        for lon in range(math.floor(x0), math.floor(x1) + 1):
            px0, py0, px1, py1 = max(x0, lon), max(y0, lat), min(x1, lon + 1), min(y1, lat + 1)
            if px1 <= px0 or py1 <= py0:
                continue
            width = max(2, round((px1 - px0) * PIXELS_PER_DEGREE))
            height = max(2, round((py1 - py0) * PIXELS_PER_DEGREE))
            query = urllib.parse.urlencode([
                ("collection", DEM_COLLECTION), ("item", _tile_id(lat, lon)), ("assets", "data"),
                ("rescale", f"{ELEV_MIN},{ELEV_MAX}"), ("resampling", "bilinear"),
            ])
            url = f"{client.data_api_url}/item/bbox/{px0},{py0},{px1},{py1}/{width}x{height}.png?{query}"
            name = f"dem_{lat}_{lon}.png"
            (out_dir / name).write_bytes(client._request(url))
            parts.append({"file": name, "bbox": [px0, py0, px1, py1], "width": width, "height": height})
    meta = {"bbox": list(bbox), "elev_min": ELEV_MIN, "elev_max": ELEV_MAX, "parts": parts,
            "source": "Copernicus DEM GLO-30 (ESA) via Microsoft Planetary Computer"}
    (out_dir / "terrain.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta
