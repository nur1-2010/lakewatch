"""Доступ к снимкам Sentinel-2 через Microsoft Planetary Computer.

Используются два публичных сервиса (регистрация не нужна):
  * STAC API — каталог: какие снимки есть над точкой за период;
  * Data API (TiTiler) — считает статистику и рисует картинки на стороне сервера,
    поэтому скачивать гигабайтные снимки не нужно.
"""

from __future__ import annotations

import json
import logging
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

from .lakes import Lake

log = logging.getLogger(__name__)
USER_AGENT = "LakeWatch/0.1 (+open lake monitoring)"


class SentinelError(RuntimeError):
    pass


@dataclass(frozen=True)
class Scene:
    item_id: str
    date: str                 # YYYY-MM-DD
    processing_baseline: str  # версия обработки ESA, например "05.11"
    scene_cloud_pct: float

    @property
    def has_radiometric_offset(self) -> bool:
        """С версии обработки 04.00 (январь 2022) ESA прибавляет +1000 ко всем значениям."""
        return self.processing_baseline >= "04.00"


class SentinelClient:
    def __init__(self, stac_url: str, data_api_url: str, collection: str,
                 timeout_s: float = 180.0, retries: int = 4):
        self.stac_url = stac_url
        self.data_api_url = data_api_url.rstrip("/")
        self.collection = collection
        self.timeout_s = timeout_s
        self.retries = retries

    # ------------------------------------------------------------ HTTP

    def _request(self, url: str, body: dict | None = None) -> bytes:
        data = json.dumps(body).encode() if body is not None else None
        headers = {"User-Agent": USER_AGENT}
        if data is not None:
            headers["Content-Type"] = "application/json"
        last_error: Exception | None = None
        for attempt in range(self.retries):
            try:
                req = urllib.request.Request(url, data, headers)
                with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                    return resp.read()
            except urllib.error.HTTPError as e:
                if e.code < 500 and e.code != 429:   # ошибка в самом запросе: повтор не поможет
                    raise SentinelError(f"HTTP {e.code} для {url[:120]}: {e.read()[:300]!r}") from e
                last_error = e
            except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
                last_error = e
            delay = 2 ** attempt * 2
            log.warning("Сбой запроса (%s), повтор через %s с", last_error, delay)
            time.sleep(delay)
        raise SentinelError(f"Сервер не ответил после {self.retries} попыток: {last_error}")

    def _json(self, url: str, body: dict | None = None) -> dict:
        return json.loads(self._request(url, body))

    # ------------------------------------------------------------ каталог

    def search_scenes(self, lake: Lake, year: int, months: tuple[int, ...],
                      scene_cloud_limit: float) -> list[Scene]:
        m1, m2 = min(months), max(months)
        last_day = 30 if m2 in (4, 6, 9, 11) else (28 if m2 == 2 else 31)
        body = {
            "collections": [self.collection],
            "bbox": list(lake.bbox),
            "datetime": f"{year}-{m1:02d}-01T00:00:00Z/{year}-{m2:02d}-{last_day}T23:59:59Z",
            "query": {"eo:cloud_cover": {"lt": scene_cloud_limit}},
            "limit": 200,
        }
        scenes: list[Scene] = []
        url, payload = self.stac_url, body
        while url:
            page = self._json(url, payload)
            for feature in page.get("features", []):
                props = feature["properties"]
                day = props["datetime"][:10]
                if int(day[5:7]) not in months:
                    continue
                scenes.append(Scene(
                    item_id=feature["id"], date=day,
                    processing_baseline=str(props.get("s2:processing_baseline", "00.00")),
                    scene_cloud_pct=float(props.get("eo:cloud_cover", 0.0)),
                ))
            # постраничная выдача STAC: ссылка "next" с новым телом запроса
            nxt = next((l for l in page.get("links", []) if l.get("rel") == "next"), None)
            url, payload = (nxt["href"], nxt.get("body")) if nxt else (None, None)
        return scenes

    # ------------------------------------------------------------ статистика

    def statistics(self, item_id: str, feature: dict, params: dict[str, str]) -> dict:
        query = urllib.parse.urlencode({"collection": self.collection, "item": item_id, **params})
        result = self._json(f"{self.data_api_url}/item/statistics?{query}", feature)
        stats = result["properties"]["statistics"]
        return stats[next(iter(stats))]

    def preview_png(self, item_id: str, bbox: tuple[float, float, float, float],
                    size: int = 800) -> bytes:
        """Картинка в естественных цветах (каналы B04, B03, B02).

        Пиксель Sentinel-2 — 10 м, поэтому маленькое озеро занимает всего десятки пикселей.
        Чтобы картинка не выглядела «кубиками», сервер увеличивает её с бикубическим
        сглаживанием (resampling=cubic). Деталей это не добавляет, но снимок читается.
        """
        query = urllib.parse.urlencode([
            ("collection", self.collection), ("item", item_id),
            ("assets", "B04"), ("assets", "B03"), ("assets", "B02"),
            # широкий диапазон яркости + гамма: видны и тёмные камни, и снег (он не «выгорает» в белое пятно)
            ("asset_as_band", "true"), ("rescale", "800,10500"),
            ("color_formula", "gamma RGB 2.2 saturation 1.2"), ("resampling", "cubic"),
        ])
        x0, y0, x1, y1 = bbox
        return self._request(f"{self.data_api_url}/item/bbox/{x0},{y0},{x1},{y1}/{size}x{size}.png?{query}")
