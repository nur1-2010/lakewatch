"""Веб-сервер: открытое API (только чтение) + раздача сайта и картинок."""

from __future__ import annotations

import csv
import io

from flask import Flask, Response, abort, jsonify, request, send_from_directory

from . import __version__
from .lakes import load_lakes
from .service import LakeService
from .settings import Settings
from .storage import Storage


def create_app(settings: Settings | None = None, service: LakeService | None = None) -> Flask:
    settings = settings or Settings()
    if service is None:
        service = LakeService(settings, Storage(settings.db_file), load_lakes(settings.config_file))

    app = Flask(__name__, static_folder=None)
    app.json.ensure_ascii = False           # кириллица в JSON без \uXXXX
    app.json.sort_keys = False
    app.config["SERVICE"] = service

    def lake_or_404(lake_id: str) -> str:
        lake_id = lake_id.removesuffix(".json")
        if lake_id not in service.lakes:
            abort(404, description="lake not found")
        return lake_id

    @app.after_request
    def headers(resp: Response) -> Response:
        if request.path.startswith("/api/"):
            resp.headers["Access-Control-Allow-Origin"] = "*"      # открытые данные
            resp.headers["Cache-Control"] = "public, max-age=300"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        return resp

    @app.errorhandler(404)
    def not_found(e):
        if request.path.startswith("/api/"):
            return jsonify(error="not_found", message=str(e.description)), 404
        return e

    # ------------------------------------------------------------ API

    @app.get("/api/health")
    def health():
        return jsonify(status="ok", version=__version__)

    @app.get("/api/meta")
    def meta():
        return jsonify(service.meta())

    @app.get("/api/lakes")
    def lakes():
        return jsonify(lakes=service.summaries())

    @app.get("/api/lakes/<lake_id>")
    def lake_detail(lake_id: str):
        return jsonify(service.detail(lake_or_404(lake_id)))

    @app.get("/api/overview")
    def overview():
        return jsonify(service.overview())

    @app.get("/api/alerts")
    def alerts():
        return jsonify(alerts=service.alerts())

    @app.get("/api/<path:name>.json")
    def as_json_file(name: str):
        """Те же данные по адресам с .json — так их запрашивает сайт (и так они лежат в статической сборке)."""
        simple = {"health": health, "meta": meta, "lakes": lakes, "overview": overview, "alerts": alerts}
        if name in simple:
            return simple[name]()
        if name.startswith("lakes/") and name.count("/") == 1:
            return lake_detail(name.split("/", 1)[1])
        abort(404, description="unknown endpoint")

    @app.get("/api/lakes/<lake_id>/observations.csv")
    def lake_csv(lake_id: str):
        detail = service.detail(lake_or_404(lake_id))
        buf = io.StringIO()
        fields = ["date", "area_m2", "scl_water_m2", "cloud_pct", "snow_pct", "valid", "rejected_reason"]
        writer = csv.DictWriter(buf, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(detail["series"])
        return Response(buf.getvalue(), mimetype="text/csv; charset=utf-8", headers={
            "Content-Disposition": f'attachment; filename="{lake_id}_observations.csv"',
            "Access-Control-Allow-Origin": "*"})

    # ------------------------------------------------------------ картинки и сайт

    @app.get("/previews/<path:file_name>")
    def previews(file_name: str):
        resp = send_from_directory(settings.previews_dir, file_name, max_age=86400)
        return resp

    @app.get("/")
    def index():
        return send_from_directory(settings.frontend_dir, "index.html", max_age=0)

    @app.get("/<path:path>")
    def frontend(path: str):
        if path.startswith("api/"):
            abort(404, description="unknown endpoint")
        # max_age=0: браузер каждый раз сверяется с сервером (ответ 304, если файл не менялся),
        # поэтому после обновления сайта посетители сразу получают новую версию
        return send_from_directory(settings.frontend_dir, path, max_age=0)

    return app
