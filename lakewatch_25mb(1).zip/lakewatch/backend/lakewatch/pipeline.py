"""Обновление данных: поиск новых снимков, измерение, картинки."""

from __future__ import annotations

import csv
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date
from pathlib import Path

from .analysis import valid_points
from .lakes import Lake
from .measure import Observation, measure_scene
from .sentinel import SentinelClient
from .settings import Settings
from .storage import Storage

log = logging.getLogger(__name__)
SAVE_EVERY = 20
PREVIEW_FRAME_SCALE = 1.8      # кадр картинки шире квадрата измерения в 1.8 раза
PREVIEW_SIZE = 800             # сторона картинки в пикселях
PREVIEW_SUFFIX = "_hd"         # отличает новые сглаженные картинки от старых маленьких


def make_client(settings: Settings) -> SentinelClient:
    return SentinelClient(settings.stac_url, settings.data_api_url, settings.collection,
                          timeout_s=settings.http_timeout_s)


def update_lake(client: SentinelClient, storage: Storage, settings: Settings, lake: Lake,
                years: range, workers: int = 6) -> tuple[int, int]:
    """Докачивает и измеряет снимки, которых ещё нет в базе. Возвращает (новых, ошибок)."""
    m = settings.measurement
    known = storage.known_item_ids(lake.id)
    scenes = [s for y in years for s in client.search_scenes(lake, y, m.months, m.scene_cloud_limit)
              if s.item_id not in known]
    log.info("%s: новых снимков %d", lake.id, len(scenes))
    if not scenes:
        return 0, 0

    done, errors, buffer = 0, 0, []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(measure_scene, client, lake, s, m): s for s in scenes}
        for fut in as_completed(futures):
            try:
                buffer.append(fut.result())
                done += 1
            except Exception as e:  # один плохой снимок не должен останавливать всё обновление
                errors += 1
                log.warning("%s / %s: %s", lake.id, futures[fut].item_id, e)
            if len(buffer) >= SAVE_EVERY:
                storage.save_observations(buffer)
                buffer = []
                log.info("%s: %d/%d", lake.id, done + errors, len(scenes))
    storage.save_observations(buffer)
    return done, errors


def pick_yearly_previews(points) -> dict[int, object]:
    """Для каждого года — один кадр: наименее облачный ближе к концу августа (озёра крупнее всего)."""
    best: dict[int, object] = {}
    for p in points:
        d = date.fromisoformat(p.date)
        score = (p.cloud_pct, abs((d - date(d.year, 8, 31)).days))
        if p.year not in best or score < best[p.year][0]:
            best[p.year] = (score, p)
    return {y: v[1] for y, v in sorted(best.items())}


def update_previews(client: SentinelClient, storage: Storage, settings: Settings, lake: Lake) -> int:
    settings.previews_dir.mkdir(parents=True, exist_ok=True)
    # картинки старого формата (маленькие, «кубиками») считаем отсутствующими и перекачиваем
    existing = {p["date"] for p in storage.previews(lake.id) if PREVIEW_SUFFIX in p["file_name"]}
    points = valid_points(storage.observations(lake.id), settings.measurement)
    chosen = pick_yearly_previews(points)
    if points:
        chosen[-1] = points[-1]                        # плюс самый свежий снимок
    added = 0
    for p in chosen.values():
        if p.date in existing:
            continue
        file_name = f"{lake.id}_{p.date}{PREVIEW_SUFFIX}.png"
        path = settings.previews_dir / file_name
        if not path.exists():
            try:
                path.write_bytes(client.preview_png(p.item_id, lake.frame_bbox(PREVIEW_FRAME_SCALE), PREVIEW_SIZE))
            except Exception as e:
                log.warning("Картинка %s не загрузилась: %s", file_name, e)
                continue
        storage.save_preview(lake.id, p.date, p.item_id, file_name)
        existing.add(p.date)
        added += 1
    return added


def run_update(settings: Settings, storage: Storage, lakes: list[Lake], start_year: int,
               end_year: int, workers: int = 6, client: SentinelClient | None = None) -> dict:
    client = client or make_client(settings)
    run_id = storage.start_run()
    total_new = total_err = 0
    try:
        for lake in lakes:
            new, err = update_lake(client, storage, settings, lake, range(start_year, end_year + 1), workers)
            total_new += new
            total_err += err
            update_previews(client, storage, settings, lake)
    finally:
        storage.finish_run(run_id, total_new, total_err)
    return {"new_observations": total_new, "errors": total_err}


def import_legacy_csv(path: Path, storage: Storage, known_lake_ids: dict[str, str]) -> int:
    """Перенос данных из первого прототипа (lake-monitor/data/results.csv).

    known_lake_ids: старый id -> новый id.
    """
    rows = []
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            new_id = known_lake_ids.get(r["lake_id"])
            if not new_id:
                continue
            areas = {float(k.split("_t")[1]): float(v) for k, v in r.items() if k.startswith("area_m2_t")}
            rows.append(Observation(
                lake_id=new_id, item_id=r["item_id"], date=r["date"], box_pixels=int(r["box_pixels"]),
                pixel_m2=float(r["pixel_m2"]), cloud_pct=float(r["cloud_pct"]), snow_pct=float(r["snow_pct"]),
                scl_water_m2=float(r["scl_water_m2"]), area_m2=areas))
    storage.save_observations(rows)
    return len(rows)
