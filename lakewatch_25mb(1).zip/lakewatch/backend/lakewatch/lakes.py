"""Описание озёр и простая геометрия вокруг них."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

LANGUAGES = ("ru", "kk", "en")
METERS_PER_DEG_LAT = 110_574.0
METERS_PER_DEG_LON_AT_EQUATOR = 111_320.0


@dataclass(frozen=True)
class Lake:
    id: str
    lon: float
    lat: float
    half_size_m: float
    role: str                      # "reference" (контрольное) или "monitored"
    name_status: str               # official | osm | descriptive
    name: dict[str, str]
    basin: dict[str, str]
    description: dict[str, str]
    elevation_m: float | None = None
    osm_id: str | None = None
    sources: tuple[str, ...] = ()
    drainage: dict | None = None      # куда течёт вода: {exit, river, downstream, path_km, path}
    glacier: dict | None = None       # ближайший ледник: {distance_m, name}
    auto: bool = False                # найдено автоматически по OpenStreetMap

    @property
    def bbox(self) -> tuple[float, float, float, float]:
        """Квадрат вокруг озера: (мин. долгота, мин. широта, макс. долгота, макс. широта)."""
        dlat = self.half_size_m / METERS_PER_DEG_LAT
        dlon = self.half_size_m / (METERS_PER_DEG_LON_AT_EQUATOR * math.cos(math.radians(self.lat)))
        return (self.lon - dlon, self.lat - dlat, self.lon + dlon, self.lat + dlat)

    def frame_bbox(self, scale: float) -> tuple[float, float, float, float]:
        """Кадр для картинки: квадрат измерения, увеличенный в scale раз (виден ледник и склоны вокруг)."""
        x0, y0, x1, y1 = self.bbox
        hx, hy = (x1 - x0) / 2 * scale, (y1 - y0) / 2 * scale
        return (self.lon - hx, self.lat - hy, self.lon + hx, self.lat + hy)

    @property
    def box_area_m2(self) -> float:
        return (2 * self.half_size_m) ** 2

    def geojson_feature(self) -> dict:
        x0, y0, x1, y1 = self.bbox
        ring = [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]
        return {"type": "Feature", "properties": {},
                "geometry": {"type": "Polygon", "coordinates": [ring]}}

    def to_public_dict(self) -> dict:
        return {
            "id": self.id, "lon": self.lon, "lat": self.lat, "bbox": list(self.bbox),
            "half_size_m": self.half_size_m,
            "role": self.role, "name_status": self.name_status, "name": self.name,
            "basin": self.basin, "description": self.description,
            "elevation_m": self.elevation_m, "osm_id": self.osm_id, "sources": list(self.sources),
            "drainage": self.drainage, "glacier": self.glacier, "auto": self.auto,
        }


class LakeConfigError(ValueError):
    pass


def _localized(raw: dict, key: str, lake_id: str) -> dict[str, str]:
    value = raw.get(key) or {}
    missing = [lang for lang in LANGUAGES if not value.get(lang)]
    if missing:
        raise LakeConfigError(f"Озеро {lake_id}: в поле '{key}' нет перевода на {', '.join(missing)}")
    return {lang: value[lang] for lang in LANGUAGES}


def load_lakes(path: Path) -> list[Lake]:
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    lakes, seen = [], set()
    for item in raw["lakes"]:
        lake_id = item["id"]
        if lake_id in seen:
            raise LakeConfigError(f"Повторяется id озера: {lake_id}")
        seen.add(lake_id)
        if not (-90 <= item["lat"] <= 90 and -180 <= item["lon"] <= 180):
            raise LakeConfigError(f"Озеро {lake_id}: неверные координаты")
        if item["half_size_m"] <= 0:
            raise LakeConfigError(f"Озеро {lake_id}: half_size_m должен быть больше нуля")
        lakes.append(Lake(
            id=lake_id, lon=float(item["lon"]), lat=float(item["lat"]),
            half_size_m=float(item["half_size_m"]), role=item.get("role", "monitored"),
            name_status=item.get("name_status", "descriptive"),
            name=_localized(item, "name", lake_id), basin=_localized(item, "basin", lake_id),
            description=_localized(item, "description", lake_id),
            elevation_m=item.get("elevation_m"), osm_id=item.get("osm_id"),
            sources=tuple(item.get("sources", ())),
            drainage=item.get("drainage"), glacier=item.get("glacier"), auto=bool(item.get("auto", False)),
        ))
    return lakes
