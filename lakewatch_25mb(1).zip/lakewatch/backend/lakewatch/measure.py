"""Измерение площади воды на одном снимке.

NDWI (Normalized Difference Water Index) = (Green − NIR) / (Green + NIR).
Вода поглощает ближний инфракрасный свет, поэтому у воды NDWI > 0, у камня и травы < 0.
Сервер возвращает гистограмму NDWI по квадрату вокруг озера; число пикселей выше порога,
умноженное на площадь пикселя, и есть площадь воды.

Карта классов SCL (Scene Classification Layer) нужна, чтобы отбросить снимки с облаками и снегом.
"""

from __future__ import annotations

from dataclasses import dataclass

from .lakes import Lake
from .sentinel import Scene, SentinelClient
from .settings import MeasurementSettings

# Коды классов SCL
SCL_CLOUDY = frozenset({0, 1, 3, 8, 9, 10})  # нет данных, пересвет, тень облака, облака, перистые
SCL_WATER = 6
SCL_SNOW = 11
HISTOGRAM_BINS = 40                           # шаг 0.05 на отрезке [-1, 1]


@dataclass(frozen=True)
class Observation:
    lake_id: str
    item_id: str
    date: str
    box_pixels: int
    pixel_m2: float
    cloud_pct: float
    snow_pct: float
    scl_water_m2: float
    area_m2: dict[float, float]       # порог NDWI -> площадь воды, м²

    def is_valid(self, s: MeasurementSettings) -> bool:
        return self.cloud_pct <= s.max_cloud_pct and self.snow_pct <= s.max_snow_pct


def ndwi_expression(scene: Scene) -> str:
    """Выражение NDWI с учётом смещения +1000 у снимков после 2022 года.

    (G−1000 − (N−1000)) / (G−1000 + N−1000) = (G − N) / (G + N − 2000).
    Если смещение не вычесть, вода выглядит «бледнее» и площадь занижается.
    """
    if scene.has_radiometric_offset:
        return "(B03-B08)/(B03+B08-2000)"
    return "(B03-B08)/(B03+B08)"


def water_pixels_above(histogram: list[float], edges: list[float], threshold: float) -> float:
    """Сколько пикселей попало в столбцы гистограммы, начинающиеся не ниже порога."""
    return sum(count for count, lower in zip(histogram, edges) if lower >= threshold - 1e-9)


def scl_breakdown(scl_stats: dict) -> tuple[dict[int, float], float]:
    counts, classes = scl_stats["histogram"]
    by_class = {int(c): float(n) for n, c in zip(counts, classes)}
    return by_class, sum(by_class.values())


def measure_scene(client: SentinelClient, lake: Lake, scene: Scene,
                  settings: MeasurementSettings) -> Observation:
    feature = lake.geojson_feature()

    scl = client.statistics(scene.item_id, feature, {"assets": "SCL", "categorical": "true"})
    by_class, scl_total = scl_breakdown(scl)
    if scl_total <= 0:
        raise ValueError(f"Пустая карта SCL для {scene.item_id}")
    cloud_pct = 100 * sum(n for c, n in by_class.items() if c in SCL_CLOUDY) / scl_total
    snow_pct = 100 * by_class.get(SCL_SNOW, 0) / scl_total
    scl_water_m2 = by_class.get(SCL_WATER, 0) * lake.box_area_m2 / scl_total

    if cloud_pct > settings.max_cloud_pct:
        # над озером облака: снимок всё равно не пойдёт в расчёт, поэтому второй запрос
        # (индекс воды) не делаем — это почти вдвое ускоряет обновление
        return Observation(
            lake_id=lake.id, item_id=scene.item_id, date=scene.date, box_pixels=int(scl_total),
            pixel_m2=round(lake.box_area_m2 / scl_total, 2), cloud_pct=round(cloud_pct, 2),
            snow_pct=round(snow_pct, 2), scl_water_m2=round(scl_water_m2, 1), area_m2={})

    ndwi = client.statistics(scene.item_id, feature, {
        "expression": ndwi_expression(scene), "asset_as_band": "true",
        "histogram_bins": str(HISTOGRAM_BINS), "histogram_range": "-1,1",
    })
    histogram, edges = ndwi["histogram"]
    total = float(ndwi["count"])
    if total <= 0:
        raise ValueError(f"Пустая гистограмма NDWI для {scene.item_id}")
    pixel_m2 = lake.box_area_m2 / total

    thresholds = sorted(set(settings.extra_thresholds) | {settings.ndwi_threshold})
    areas = {t: round(water_pixels_above(histogram, edges, t) * pixel_m2, 1) for t in thresholds}

    return Observation(
        lake_id=lake.id, item_id=scene.item_id, date=scene.date, box_pixels=int(total),
        pixel_m2=round(pixel_m2, 2), cloud_pct=round(cloud_pct, 2), snow_pct=round(snow_pct, 2),
        scl_water_m2=round(scl_water_m2, 1), area_m2=areas,
    )
