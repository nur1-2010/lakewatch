"""Поиск всех высокогорных озёр района и определение, куда из них течёт вода.

1. Озёра, ледники, реки и вершины берутся из OpenStreetMap (Overpass API).
2. Высота озера и путь стока считаются по карте высот Copernicus DEM
   (frontend/assets/terrain/, её готовит команда `terrain`).
3. Путь стока: от озера «разливаемся» вниз по рельефу, всегда продолжая из самой низкой
   достигнутой точки, пока не дойдём до края карты. Так вода проходит и мелкие ямки рельефа.
   По пути смотрим, какие реки с названием встречаются: последняя — та, в которую впадает сток.

Результат записывается в config/lakes.json. Названия найденных озёр — рабочие,
по ближайшему леднику или вершине; это честно помечается на сайте.
"""

from __future__ import annotations

import heapq
import json
import math
import struct
import time
import urllib.parse
import urllib.request
import zlib
from pathlib import Path

OVERPASS_URLS = ("https://overpass-api.de/api/interpreter",
                 "https://overpass.kumi.systems/api/interpreter",
                 "https://overpass.private.coffee/api/interpreter")
LANGS = ("ru", "kk", "en")
KM_LAT = 110.574

# Какой город стоит ниже по течению реки (по русскому названию реки или притока в OpenStreetMap).
DOWNSTREAM = (
    (("Малая Алма", "Киши Алматы", "Горельник", "Шымбулак"), "almaty"),
    (("Большая Алма", "Улкен Алматы", "Озёрная", "Озерная", "Проходная", "Кумбель", "Терисбутак"), "almaty"),
    (("Талгар",), "talgar"),
)


# ------------------------------------------------------------------ карта высот

def read_png_first_channel(path: Path) -> tuple[int, int, list[bytes]]:
    """Минимальный разбор PNG на стандартной библиотеке: возвращает ширину, высоту и строки первого канала."""
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"{path} — не PNG")
    pos, idat, palette = 8, b"", None
    width = height = depth = ctype = 0
    while pos < len(data):
        length = int.from_bytes(data[pos:pos + 4], "big")
        kind, chunk = data[pos + 4:pos + 8], data[pos + 8:pos + 8 + length]
        pos += 12 + length
        if kind == b"IHDR":
            width, height, depth, ctype, _, _, interlace = struct.unpack(">IIBBBBB", chunk)
            if interlace or depth not in (8, 16):
                raise ValueError("неподдерживаемый формат PNG")
        elif kind == b"PLTE":
            palette = chunk
        elif kind == b"IDAT":
            idat += chunk
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[ctype]
    bpp = channels * depth // 8
    stride = width * bpp
    raw = zlib.decompress(idat)
    rows, prev, p = [], bytearray(stride), 0
    for _ in range(height):
        ftype, line = raw[p], bytearray(raw[p + 1:p + 1 + stride])
        p += 1 + stride
        for i in range(stride):
            a = line[i - bpp] if i >= bpp else 0
            b = prev[i]
            c = prev[i - bpp] if i >= bpp else 0
            if ftype == 1:
                line[i] = (line[i] + a) & 255
            elif ftype == 2:
                line[i] = (line[i] + b) & 255
            elif ftype == 3:
                line[i] = (line[i] + ((a + b) >> 1)) & 255
            elif ftype == 4:
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                line[i] = (line[i] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
        first = bytes(line[0::bpp])
        if ctype == 3 and palette:
            first = bytes(palette[v * 3] for v in first)
        rows.append(first)
        prev = line
    return width, height, rows


class Terrain:
    """Сетка высот (метры) с переводом координат. Строка 0 — север."""

    def __init__(self, terrain_dir: Path):
        meta = json.loads((terrain_dir / "terrain.json").read_text(encoding="utf-8"))
        self.x0, self.y0, self.x1, self.y1 = meta["bbox"]
        first = meta["parts"][0]
        ppd_x = first["width"] / (first["bbox"][2] - first["bbox"][0])
        ppd_y = first["height"] / (first["bbox"][3] - first["bbox"][1])
        self.w, self.h = round((self.x1 - self.x0) * ppd_x), round((self.y1 - self.y0) * ppd_y)
        self.z = [[float(meta["elev_min"])] * self.w for _ in range(self.h)]
        span = meta["elev_max"] - meta["elev_min"]
        for part in meta["parts"]:
            pw, ph, rows = read_png_first_channel(terrain_dir / part["file"])
            dx, dy = round((part["bbox"][0] - self.x0) * ppd_x), round((self.y1 - part["bbox"][3]) * ppd_y)
            for j in range(min(ph, self.h - dy)):
                row = rows[j]
                for i in range(min(pw, self.w - dx)):
                    self.z[dy + j][dx + i] = meta["elev_min"] + row[i] / 255 * span
        self.km_lon = 111.32 * math.cos(math.radians((self.y0 + self.y1) / 2))

    def cell(self, lon: float, lat: float) -> tuple[int, int]:
        i = round((lon - self.x0) / (self.x1 - self.x0) * (self.w - 1))
        j = round((self.y1 - lat) / (self.y1 - self.y0) * (self.h - 1))
        return min(self.w - 1, max(0, i)), min(self.h - 1, max(0, j))

    def lonlat(self, i: int, j: int) -> tuple[float, float]:
        return (self.x0 + i / (self.w - 1) * (self.x1 - self.x0), self.y1 - j / (self.h - 1) * (self.y1 - self.y0))

    def contains(self, lon: float, lat: float) -> bool:
        return self.x0 <= lon <= self.x1 and self.y0 <= lat <= self.y1

    def elevation(self, lon: float, lat: float) -> float:
        i, j = self.cell(lon, lat)
        return self.z[j][i]

    def flow_path(self, lon: float, lat: float) -> tuple[list[tuple[float, float]], str]:
        """Путь воды от точки до края карты и сторона, через которую он выходит."""
        start = self.cell(lon, lat)
        parent, heap = {start: None}, [(self.z[start[1]][start[0]], start)]
        end = start
        while heap:
            _, (i, j) = heapq.heappop(heap)
            if i in (0, self.w - 1) or j in (0, self.h - 1):
                end = (i, j)
                break
            for di in (-1, 0, 1):
                for dj in (-1, 0, 1):
                    n = (i + di, j + dj)
                    if n not in parent:
                        parent[n] = (i, j)
                        heapq.heappush(heap, (self.z[n[1]][n[0]], n))
        path, cur = [], end
        while cur is not None:
            path.append(self.lonlat(*cur))
            cur = parent[cur]
        path.reverse()
        i, j = end
        side = "north" if j == 0 else "south" if j == self.h - 1 else "west" if i == 0 else "east"
        return path, side


# ------------------------------------------------------------------ OpenStreetMap

def overpass(query: str) -> list[dict]:
    body = urllib.parse.urlencode({"data": query}).encode()
    last: Exception | None = None
    for attempt in range(2):
        for url in OVERPASS_URLS:
            try:
                req = urllib.request.Request(url, body, {"User-Agent": "LakeWatch/0.1 (lake discovery)"})
                with urllib.request.urlopen(req, timeout=120) as resp:
                    return json.load(resp)["elements"]
            except Exception as e:  # сервер перегружен — пробуем следующий
                last = e
        time.sleep(5 * (attempt + 1))
    raise RuntimeError(f"Overpass не ответил: {last}")


def _points(element: dict) -> list[tuple[float, float]]:
    pts = [(g["lon"], g["lat"]) for g in element.get("geometry", [])]
    for m in element.get("members", []):
        if m.get("role") != "inner":
            pts += [(g["lon"], g["lat"]) for g in m.get("geometry", [])]
    if not pts and "lon" in element:
        pts = [(element["lon"], element["lat"])]
    return pts


def _ring_area_m2(ring: list[tuple[float, float]], km_lon: float) -> float:
    s = 0.0
    for (x1, y1), (x2, y2) in zip(ring, ring[1:] + ring[:1]):
        s += (x1 * km_lon) * (y2 * KM_LAT) - (x2 * km_lon) * (y1 * KM_LAT)
    return abs(s) / 2 * 1e6


def _area_m2(element: dict, km_lon: float) -> float:
    if element["type"] == "way":
        return _ring_area_m2([(g["lon"], g["lat"]) for g in element.get("geometry", [])], km_lon)
    return sum(_ring_area_m2([(g["lon"], g["lat"]) for g in m.get("geometry", [])], km_lon)
               for m in element.get("members", []) if m.get("role") != "inner" and m.get("geometry"))


def _names(tags: dict) -> dict[str, str] | None:
    base = tags.get("name:ru") or tags.get("name")
    if not base:
        return None
    return {"ru": tags.get("name:ru") or base, "kk": tags.get("name:kk") or tags.get("name") or base,
            "en": tags.get("name:en") or tags.get("name") or base}


def _dist_m(a: tuple[float, float], b: tuple[float, float], km_lon: float) -> float:
    return math.hypot((a[0] - b[0]) * km_lon, (a[1] - b[1]) * KM_LAT) * 1000


# ------------------------------------------------------------------ сток

def drainage_for(terrain: Terrain, lon: float, lat: float, waterways: list[dict]) -> dict:
    path, side = terrain.flow_path(lon, lat)
    river = None
    for point in path[2:]:                      # первые клетки — само озеро
        best = None
        for w in waterways:
            d = min(_dist_m(point, p, terrain.km_lon) for p in w["points"])
            if d <= 260 and (best is None or d < best[0]):
                best = (d, w)
        if best:
            river = best[1]                     # запоминаем последнюю встреченную реку
    downstream = None
    if river:
        for keys, town in DOWNSTREAM:
            if any(k.lower() in river["names"]["ru"].lower() for k in keys):
                downstream = town
    length_km = sum(_dist_m(a, b, terrain.km_lon) for a, b in zip(path, path[1:])) / 1000
    return {"exit": side, "river": river["names"] if river else None, "downstream": downstream,
            "path_km": round(length_km, 1),
            "path": [[round(x, 5), round(y, 5)] for x, y in path[::2] + path[-1:]]}


# ------------------------------------------------------------------ главный шаг

def discover(config_file: Path, terrain_dir: Path, min_area_m2: float = 1500.0,
             min_elevation_m: float = 2900.0, dry_run: bool = False) -> dict:
    terrain = Terrain(terrain_dir)
    s, w, n, e = terrain.y0, terrain.x0, terrain.y1, terrain.x1
    box = f"({s},{w},{n},{e})"
    elements = overpass(
        "[out:json][timeout:90];("
        f'way["natural"="water"]{box};relation["natural"="water"]{box};'
        f'way["natural"="glacier"]{box};relation["natural"="glacier"]{box};'
        f'way["waterway"]["name"]{box};node["natural"~"^(peak|saddle)$"]["name"]{box};'
        ");out tags geom;")

    glaciers, waterways, landmarks, waters = [], [], [], []
    for el in elements:
        tags, pts = el.get("tags", {}), _points(el)
        if not pts:
            continue
        if tags.get("natural") == "glacier":
            glaciers.append({"names": _names(tags), "points": pts})
        elif tags.get("waterway") and _names(tags):
            waterways.append({"names": _names(tags), "points": pts, "kind": tags["waterway"]})
        elif tags.get("natural") in ("peak", "saddle") and _names(tags):
            landmarks.append({"names": _names(tags), "points": pts, "kind": tags["natural"]})
        elif tags.get("natural") == "water" and tags.get("water") in (None, "lake", "pond"):
            waters.append(el)

    raw = json.loads(config_file.read_text(encoding="utf-8"))
    lakes = raw["lakes"]

    def nearest(items, point, need_name=True):
        best = None
        for it in items:
            if need_name and not it["names"]:
                continue
            d = min(_dist_m(point, p, terrain.km_lon) for p in it["points"])
            if best is None or d < best[0]:
                best = (d, it)
        return best

    def enrich(lake: dict) -> None:
        point = (lake["lon"], lake["lat"])
        if not terrain.contains(*point):
            return
        lake["elevation_m"] = round(terrain.elevation(*point) / 10) * 10
        lake["drainage"] = drainage_for(terrain, lake["lon"], lake["lat"], waterways)
        g = nearest(glaciers, point, need_name=False)
        gn = nearest(glaciers, point)
        lake["glacier"] = None if not g else {
            "distance_m": round(g[0] / 10) * 10,
            "name": gn[1]["names"] if gn and gn[0] <= 1500 else None}

    for lake in lakes:
        enrich(lake)

    used: dict[str, int] = {}
    added = []
    for el in waters:
        pts = _points(el)
        lon = sum(p[0] for p in pts) / len(pts)
        lat = sum(p[1] for p in pts) / len(pts)
        area = _area_m2(el, terrain.km_lon)
        if area < min_area_m2 or not terrain.contains(lon, lat) or terrain.elevation(lon, lat) < min_elevation_m:
            continue
        if any(_dist_m((lon, lat), (l["lon"], l["lat"]), terrain.km_lon) < 300 for l in lakes):
            continue
        tags = el.get("tags", {})
        g, lm = nearest(glaciers, (lon, lat)), nearest(landmarks, (lon, lat))
        own = _names(tags)
        # собственное название из OSM берём, только если оно перекликается с соседним объектом
        # (защита от шуточных названий, которые иногда появляются на карте)
        anchors = [x[1]["names"]["ru"] for x in (g, lm) if x and x[0] <= 2500]
        if own and not any(own["ru"][:5].lower() in a.lower() or a[:5].lower() in own["ru"].lower() for a in anchors):
            own = None
        if own:
            name = {"ru": f"Озеро {own['ru']}", "kk": f"{own['kk']} көлі", "en": f"Lake {own['en']}"}
            status, key = "osm", own["ru"]
        elif g and g[0] <= 1500:
            gn = g[1]["names"]
            name = {"ru": f"Озеро у ледника {gn['ru']}", "kk": f"{gn['kk']} мұздығы маңындағы көл",
                    "en": f"Lake near {gn['en']} Glacier"}
            status, key = "descriptive", "g:" + gn["ru"]
        elif lm:
            ln, peak = lm[1]["names"], lm[1]["kind"] == "peak"
            name = {"ru": f"Озеро у {'пика' if peak else 'перевала'} {ln['ru']}",
                    "kk": f"{ln['kk']} {'шыңы' if peak else 'асуы'} маңындағы көл",
                    "en": f"Lake near {ln['en']} {'Peak' if peak else 'Pass'}"}
            status, key = "descriptive", "l:" + ln["ru"]
        else:
            continue
        used[key] = used.get(key, 0) + 1
        if used[key] > 1:
            name = {k: f"{v} №{used[key]}" if k != "en" else f"{v} No. {used[key]}" for k, v in name.items()}

        extent_m = max((max(p[0] for p in pts) - min(p[0] for p in pts)) * terrain.km_lon,
                       (max(p[1] for p in pts) - min(p[1] for p in pts)) * KM_LAT) * 1000
        half = min(700, max(250, math.ceil((extent_m / 2 + 120) / 50) * 50))
        lake = {
            "id": f"osm_{el['type']}_{el['id']}", "lon": round(lon, 5), "lat": round(lat, 5),
            "half_size_m": half, "elevation_m": None, "role": "monitored", "name_status": status,
            "osm_id": f"{el['type']}/{el['id']}", "name": name, "osm_area_m2": round(area, -1),
            "basin": {"ru": "Иле-Алатау", "kk": "Іле Алатауы", "en": "Ile Alatau"},
            "description": {
                "ru": "Высокогорное озеро, найденное по карте OpenStreetMap. Название рабочее — по ближайшему леднику или вершине.",
                "kk": "OpenStreetMap картасы бойынша табылған биік таулы көл. Атауы жұмыс атауы — ең жақын мұздық немесе шың бойынша.",
                "en": "A high-mountain lake found on OpenStreetMap. The name is a working one, after the nearest glacier or peak.",
            },
            "sources": [f"OpenStreetMap {el['type']}/{el['id']}"], "auto": True,
        }
        enrich(lake)
        lakes.append(lake)
        added.append(lake)

    if not dry_run:
        config_file.write_text(json.dumps(raw, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"added": added, "total": len(lakes), "glaciers": len(glaciers), "waterways": len(waterways)}
