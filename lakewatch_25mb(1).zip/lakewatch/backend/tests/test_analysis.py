import unittest
from datetime import date

from lakewatch.analysis import analyze, chart_series, theil_sen_slope, valid_points, yearly_medians
from lakewatch.settings import AnalysisSettings, MeasurementSettings

from helpers import obs, seasons

M, A = MeasurementSettings(), AnalysisSettings()
TODAY = date(2026, 11, 14)


def keys(result):
    return [f["key"] for f in result["findings"]]


class StatusTests(unittest.TestCase):
    def test_stable_lake(self):
        r = analyze(seasons({y: [10_000, 10_200, 9_900, 10_100] for y in range(2019, 2027)}), M, A, today=TODAY)
        self.assertEqual(r["status"], "stable")
        self.assertEqual(r["level"], "normal")
        self.assertEqual(keys(r)[0], "headline.stable")
        self.assertEqual(r["trend"]["direction"], "flat")

    def test_rapid_rise_against_normal(self):
        data = {y: [20_000] * 4 for y in range(2019, 2026)}
        data[2026] = [30_000, 31_000, 29_000, 30_500]
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertEqual(r["status"], "rapid_rise")
        self.assertEqual(r["level"], "alert")
        self.assertAlmostEqual(r["change_vs_normal_pct"], 51.2, places=1)
        self.assertEqual(r["normal"]["year_from"], 2019)
        self.assertEqual(r["normal"]["year_to"], 2025)
        self.assertIn("record.max_now", keys(r))

    def test_small_absolute_growth_is_not_rapid(self):
        data = {y: [1_000] * 4 for y in range(2019, 2026)}
        data[2026] = [1_600] * 4                       # +60%, но всего +600 м² — это шум, а не рост
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertEqual(r["status"], "stable")

    def test_return_to_usual_size_is_not_rapid_rise(self):
        # два маловодных года занизили норму; возврат к прежней площади — не «быстрый рост»
        data = {2019: [7_600] * 4, 2020: [6_700] * 4, 2021: [5_800] * 4, 2022: [300] * 4,
                2023: [200] * 4, 2024: [300] * 4, 2025: [250] * 4, 2026: [6_100] * 4}
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertNotEqual(r["status"], "rapid_rise")

    def test_steady_growth_of_small_lake_is_rising(self):
        data = {2019: [2_700] * 4, 2020: [2_700] * 4, 2021: [3_900] * 4, 2022: [4_700] * 4,
                2023: [4_700] * 4, 2024: [5_600] * 4, 2025: [5_600] * 4, 2026: [5_900] * 4}
        self.assertEqual(analyze(seasons(data), M, A, today=TODAY)["status"], "rising")

    def test_lake_that_dried_up_does_not_crash(self):
        # воды в последний год нет: раньше здесь было деление на ноль, из-за которого падал сайт
        data = {y: [8_000] * 4 for y in range(2019, 2026)}
        data[2026] = [0] * 4
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertEqual(r["status"], "falling")
        self.assertIn("multi_year.gone", keys(r))

    def test_lake_always_empty_does_not_crash(self):
        r = analyze(seasons({y: [0] * 4 for y in range(2019, 2027)}), M, A, today=TODAY)
        self.assertEqual(r["status"], "stable")
        self.assertEqual(r["max_yearly_m2"], 0)

    def test_new_lake(self):
        data = {2019: [0] * 4, 2020: [0] * 4, 2021: [100] * 4, 2022: [800] * 4,
                2023: [1_200] * 4, 2024: [1_500] * 4, 2025: [2_000] * 4, 2026: [2_300] * 4}
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertEqual(r["status"], "new_lake")
        self.assertEqual(r["new_lake"]["appeared_year"], 2022)
        self.assertEqual(keys(r)[0], "headline.new_lake")
        self.assertIn("data.small_lake", keys(r))

    def test_falling(self):
        data = {y: [10_000] * 4 for y in range(2019, 2026)}
        data[2026] = [7_000] * 4
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertEqual(r["status"], "falling")

    def test_insufficient_data(self):
        r = analyze(seasons({2025: [5_000] * 3, 2026: [5_000] * 3}), M, A, today=TODAY)
        self.assertEqual(r["status"], "insufficient_data")
        self.assertEqual(keys(r)[0], "headline.insufficient")

    def test_late_season_drop_does_not_fake_a_fall(self):
        # конец сентября: озеро начинает замерзать — это не должно выглядеть как «уменьшение»
        data = {y: [10_000] * 6 for y in range(2019, 2026)}
        data[2026] = [10_000, 10_100, 9_900, 10_000, 4_000, 3_500]
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertEqual(r["status"], "stable")
        self.assertEqual(r["season"]["direction"], "down")

    def test_reference_note(self):
        r = analyze(seasons({y: [10_000] * 4 for y in range(2019, 2027)}), M, A, role="reference", today=TODAY)
        self.assertIn("note.reference", keys(r))

    def test_off_season_note(self):
        r = analyze(seasons({y: [10_000] * 4 for y in range(2019, 2027)}), M, A, today=TODAY)
        self.assertIn("data.off_season", keys(r))


class ComparisonTests(unittest.TestCase):
    def test_year_over_year_up(self):
        data = {y: [10_000] * 4 for y in range(2019, 2026)}
        data[2026] = [12_000] * 4
        r = analyze(seasons(data), M, A, today=TODAY)
        yoy = r["year_over_year"]
        self.assertEqual((yoy["year"], yoy["prev_year"], yoy["direction"]), (2026, 2025, "up"))
        self.assertAlmostEqual(yoy["change_pct"], 20.0)
        self.assertEqual(yoy["change_m2"], 2_000)
        self.assertIn("yoy.up", keys(r))

    def test_year_over_year_flat_and_down(self):
        base = {y: [10_000] * 4 for y in range(2019, 2026)}
        flat = analyze(seasons({**base, 2026: [10_200] * 4}), M, A, today=TODAY)
        self.assertIn("yoy.flat", keys(flat))
        down = analyze(seasons({**base, 2026: [9_000] * 4}), M, A, today=TODAY)
        self.assertIn("yoy.down", keys(down))

    def test_growth_streak(self):
        data = {2019: [10_000] * 4, 2020: [10_000] * 4, 2021: [10_000] * 4, 2022: [9_000] * 4,
                2023: [10_000] * 4, 2024: [11_000] * 4, 2025: [12_000] * 4, 2026: [13_000] * 4}
        r = analyze(seasons(data), M, A, today=TODAY)
        self.assertEqual(r["streak"], {"direction": "up", "years": 4, "since_year": 2022})
        self.assertIn("streak.up", keys(r))

    def test_no_streak_for_single_step(self):
        data = {y: [10_000] * 4 for y in range(2019, 2026)}
        data[2026] = [12_000] * 4
        self.assertIsNone(analyze(seasons(data), M, A, today=TODAY)["streak"])

    def test_rank_and_since_start(self):
        data = {2019: [10_000] * 4, 2020: [14_000] * 4, 2021: [12_000] * 4, 2022: [11_000] * 4}
        r = analyze(seasons(data), M, A, today=date(2022, 11, 1))
        self.assertEqual(r["rank"], {"year": 2022, "position": 3, "total": 4})
        self.assertAlmostEqual(r["since_start"]["change_pct"], 10.0)
        self.assertIn("rank.position", keys(r))

    def test_yearly_rows_have_change(self):
        r = analyze(seasons({2024: [10_000] * 4, 2025: [11_000] * 4, 2026: [11_000] * 4}), M, A, today=TODAY)
        self.assertIsNone(r["yearly"][0]["change_pct"])
        self.assertAlmostEqual(r["yearly"][1]["change_pct"], 10.0)
        self.assertEqual(r["yearly"][1]["observations"], 4)

    def test_volume_estimate_and_meaning(self):
        r = analyze(seasons({y: [10_000] * 4 for y in range(2019, 2027)}), M, A, today=TODAY)
        self.assertAlmostEqual(r["volume_estimate"]["m3"], 0.104 * 10_000 ** 1.42, delta=100)
        self.assertEqual(r["meaning"], "meaning.stable")
        ref = analyze(seasons({y: [10_000] * 4 for y in range(2019, 2027)}), M, A, role="reference", today=TODAY)
        self.assertIsNone(ref["volume_estimate"])
        self.assertIsNone(ref["meaning"])


class HelperTests(unittest.TestCase):
    def test_cloudy_and_snowy_images_are_rejected(self):
        pts = valid_points([obs("2025-07-01", 100), obs("2025-07-02", 999, cloud=50),
                            obs("2025-07-03", 999, snow=80)], M)
        self.assertEqual([p.date for p in pts], ["2025-07-01"])

    def test_same_day_keeps_least_cloudy(self):
        pts = valid_points([obs("2025-07-01", 100, cloud=10, item="a"), obs("2025-07-01", 200, cloud=1, item="b")], M)
        self.assertEqual(len(pts), 1)
        self.assertEqual(pts[0].area_m2, 200)

    def test_main_threshold_is_used(self):
        pts = valid_points([obs("2025-07-01", 100)], M)
        self.assertEqual(pts[0].area_m2, 100)          # порог 0.2, а не 0.0 (150)

    def test_yearly_medians(self):
        pts = valid_points(seasons({2024: [1, 2, 30], 2025: [5, 5]}), M)
        self.assertEqual(yearly_medians(pts), {2024: 2, 2025: 5})

    def test_theil_sen_ignores_outlier(self):
        self.assertAlmostEqual(theil_sen_slope([1, 2, 3, 4, 5], [1, 2, 3, 4, 100]), 1.0)
        self.assertIsNone(theil_sen_slope([1], [1]))

    def test_chart_series_marks_rejections(self):
        s = chart_series([obs("2025-07-01", 100, cloud=50), obs("2025-07-02", 100, snow=90), obs("2025-07-03", 100)], M)
        self.assertEqual([p["rejected_reason"] for p in s], ["clouds", "snow", None])


if __name__ == "__main__":
    unittest.main()
