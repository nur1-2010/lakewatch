import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from lakewatch.api import create_app
from lakewatch.lakes import LakeConfigError, load_lakes
from lakewatch.service import LakeService
from lakewatch.settings import PROJECT_ROOT, Settings
from lakewatch.storage import Storage

from helpers import make_lake, seasons

FRONTEND = PROJECT_ROOT / "frontend"


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        tmp = Path(self.tmp.name)
        self.settings = replace(Settings(), data_dir=tmp, frontend_dir=FRONTEND)
        storage = Storage(self.settings.db_file)
        data = {y: [20_000] * 4 for y in range(2019, 2026)}
        data[2026] = [30_000] * 4
        storage.save_observations(seasons(data))
        self.service = LakeService(self.settings, storage, [make_lake()])
        self.client = create_app(self.settings, self.service).test_client()

    def tearDown(self):
        self.tmp.cleanup()

    def test_health(self):
        self.assertEqual(self.client.get("/api/health").get_json()["status"], "ok")

    def test_lakes_list(self):
        resp = self.client.get("/api/lakes")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.headers["Access-Control-Allow-Origin"], "*")
        lake = resp.get_json()["lakes"][0]
        self.assertEqual(lake["id"], "test_lake")
        self.assertIn(lake["status"], {"stable", "rapid_rise", "rising"})
        self.assertIn("headline", lake)

    def test_detail_and_404(self):
        d = self.client.get("/api/lakes/test_lake").get_json()
        self.assertIn("findings", d["analysis"])
        self.assertTrue(d["series"])
        r = self.client.get("/api/lakes/nope")
        self.assertEqual(r.status_code, 404)
        self.assertEqual(r.get_json()["error"], "not_found")

    def test_overview(self):
        o = self.client.get("/api/overview").get_json()
        self.assertEqual(o["lakes_monitored"], 1)
        self.assertEqual(o["lakes_attention"], 1)
        self.assertEqual((o["year_from"], o["year_to"]), (2019, 2026))
        self.assertEqual(o["total_area"]["direction"], "up")
        self.assertAlmostEqual(o["total_area"]["change_pct"], 50.0)

    def test_csv(self):
        r = self.client.get("/api/lakes/test_lake/observations.csv")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.data.decode().startswith("date,area_m2"))

    def test_frontend_served(self):
        r = self.client.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn(b"LakeWatch", r.data)
        r.close()
        r = self.client.get("/js/app.js")
        self.assertEqual(r.status_code, 200)
        r.close()


class TranslationTests(unittest.TestCase):
    def load(self, lang):
        return json.loads((FRONTEND / "i18n" / f"{lang}.json").read_text(encoding="utf-8"))

    def test_all_languages_have_same_keys(self):
        ru = set(self.load("ru"))
        for lang in ("kk", "en"):
            other = set(self.load(lang))
            self.assertEqual(ru - other, set(), f"в {lang}.json не хватает ключей")
            self.assertEqual(other - ru, set(), f"в {lang}.json лишние ключи")

    def test_placeholders_match(self):
        import re
        ru, kk, en = self.load("ru"), self.load("kk"), self.load("en")
        for key, text in ru.items():
            want = set(re.findall(r"\{(\w+)\}", text))
            for name, d in (("kk", kk), ("en", en)):
                self.assertEqual(set(re.findall(r"\{(\w+)\}", d[key])), want, f"{name}: {key}")

    def test_every_backend_message_is_translated(self):
        ru = self.load("ru")
        source = (PROJECT_ROOT / "backend" / "lakewatch" / "analysis.py").read_text(encoding="utf-8")
        import re
        literal = set(re.findall(r'"key": "([a-z_]+\.[a-z_]+)"', source))
        dynamic = {f"headline.{s}" for s in ("rapid_rise", "rising", "falling")} | \
                  {f"trend.{d}" for d in ("up", "down", "flat")} | {f"season.{d}" for d in ("up", "down", "flat")} | \
                  {"data.off_season", "data.no_recent", "multi_year.grew", "multi_year.shrank"} | \
                  {f"yoy.{d}" for d in ("up", "down", "flat")} | {f"streak.{d}" for d in ("up", "down")} | \
                  {f"overview.total.{d}" for d in ("up", "down", "flat")}
        for key in literal | dynamic:
            self.assertIn(key, ru, key)
        for status in ("rapid_rise", "rising", "new_lake", "stable", "falling", "insufficient_data"):
            self.assertIn(f"meaning.{status}", ru)
        for status in ("rapid_rise", "rising", "new_lake", "stable", "falling", "insufficient_data"):
            self.assertIn(f"status.{status}", ru)


class ConfigTests(unittest.TestCase):
    def test_project_config_is_valid(self):
        lakes = load_lakes(PROJECT_ROOT / "config" / "lakes.json")
        self.assertGreaterEqual(len(lakes), 4)
        for lake in lakes:
            x0, y0, x1, y1 = lake.bbox
            self.assertLess(x0, lake.lon)
            self.assertLess(lake.lat, y1)

    def test_missing_translation_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "lakes.json"
            p.write_text(json.dumps({"lakes": [{"id": "a", "lon": 77, "lat": 43, "half_size_m": 100,
                                                 "name": {"ru": "А"}, "basin": {}, "description": {}}]}),
                         encoding="utf-8")
            with self.assertRaises(LakeConfigError):
                load_lakes(p)


if __name__ == "__main__":
    unittest.main()
