from __future__ import annotations

from lakewatch.lakes import Lake
from lakewatch.measure import Observation

TR = {"ru": "x", "kk": "x", "en": "x"}


def make_lake(lake_id: str = "test_lake", role: str = "monitored") -> Lake:
    return Lake(id=lake_id, lon=77.0, lat=43.0, half_size_m=500, role=role, name_status="descriptive",
                name={"ru": "Тест", "kk": "Тест", "en": "Test"}, basin=TR, description=TR)


def obs(day: str, area: float, cloud: float = 0.0, snow: float = 0.0, lake_id: str = "test_lake",
        item: str | None = None) -> Observation:
    return Observation(lake_id=lake_id, item_id=item or f"S2_{day}", date=day, box_pixels=10_000,
                       pixel_m2=100.0, cloud_pct=cloud, snow_pct=snow, scl_water_m2=area,
                       area_m2={0.0: area * 1.5, 0.1: area * 1.2, 0.2: area})


def seasons(areas_by_year: dict[int, list[float]]) -> list[Observation]:
    """Ряд наблюдений: для каждого года — снимки с 1 июля через каждые 7 дней."""
    out = []
    for year, areas in areas_by_year.items():
        for i, a in enumerate(areas):
            month, day = (7, 1 + 7 * i) if i < 4 else (8, 1 + 7 * (i - 4))
            out.append(obs(f"{year}-{month:02d}-{day:02d}", a))
    return out
