import unittest

from lakewatch.measure import measure_scene, ndwi_expression, water_pixels_above
from lakewatch.sentinel import Scene
from lakewatch.settings import MeasurementSettings

from helpers import make_lake


class FakeClient:
    """Отдаёт заранее заданную статистику вместо запросов к серверу."""

    def __init__(self, scl, ndwi):
        self.scl, self.ndwi, self.calls = scl, ndwi, []

    def statistics(self, item_id, feature, params):
        self.calls.append(params)
        return self.scl if params.get("assets") == "SCL" else self.ndwi


def ndwi_hist(counts_by_lower_edge: dict[float, int]):
    edges = [round(-1 + 0.05 * i, 2) for i in range(41)]
    hist = [counts_by_lower_edge.get(e, 0) for e in edges[:-1]]
    return {"histogram": [hist, edges], "count": sum(hist)}


class MeasureTests(unittest.TestCase):
    def test_offset_after_2022(self):
        self.assertEqual(ndwi_expression(Scene("a", "2025-07-01", "05.11", 0)), "(B03-B08)/(B03+B08-2000)")
        self.assertEqual(ndwi_expression(Scene("a", "2020-07-01", "02.14", 0)), "(B03-B08)/(B03+B08)")

    def test_water_pixels_above(self):
        h = ndwi_hist({-0.5: 10, 0.1: 5, 0.2: 7, 0.45: 3})
        self.assertEqual(water_pixels_above(h["histogram"][0], h["histogram"][1], 0.2), 10)
        self.assertEqual(water_pixels_above(h["histogram"][0], h["histogram"][1], 0.0), 15)

    def test_measure_scene(self):
        lake = make_lake()                                       # квадрат 1000×1000 м = 10 000 пикселей
        scl = {"histogram": [[9_000, 500, 400, 100], [5, 6, 8, 11]]}
        ndwi = ndwi_hist({-0.3: 9_000, 0.0: 300, 0.25: 700})
        o = measure_scene(FakeClient(scl, ndwi), lake, Scene("item", "2025-08-01", "05.11", 3), MeasurementSettings())
        self.assertEqual(o.box_pixels, 10_000)
        self.assertAlmostEqual(o.pixel_m2, 100.0)
        self.assertAlmostEqual(o.cloud_pct, 4.0)                 # класс 8
        self.assertAlmostEqual(o.snow_pct, 1.0)                  # класс 11
        self.assertAlmostEqual(o.scl_water_m2, 50_000.0)         # класс 6
        self.assertAlmostEqual(o.area_m2[0.2], 70_000.0)
        self.assertAlmostEqual(o.area_m2[0.0], 100_000.0)
        self.assertTrue(o.is_valid(MeasurementSettings()))

    def test_empty_histogram_raises(self):
        with self.assertRaises(ValueError):
            measure_scene(FakeClient({"histogram": [[], []]}, ndwi_hist({})), make_lake(),
                          Scene("i", "2025-08-01", "05.11", 0), MeasurementSettings())


if __name__ == "__main__":
    unittest.main()
